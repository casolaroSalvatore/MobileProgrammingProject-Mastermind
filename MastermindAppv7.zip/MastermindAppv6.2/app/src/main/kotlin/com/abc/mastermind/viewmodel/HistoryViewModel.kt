package com.abc.mastermind.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.abc.mastermind.data.MastermindDatabase
import com.abc.mastermind.data.repository.GameRepository
import com.abc.mastermind.domain.model.GameSettings
import kotlinx.coroutines.flow.*
import java.time.LocalDateTime

// Rappresenta un item della cronologia per la lista della UI
data class HistoryItem(
    val id: Long,                  // ID univoco della partita
    val date: LocalDateTime,       // Data e ora della partita
    val attempts: Int,             // Numero di tentativi effettuati
    val won: Boolean,              // True se l'ultimo tentativo ha indovinato il codice
    val settings: GameSettings     // Impostazioni usate per quella partita
)

// ViewModel che fornisce alla UI la lista delle partite concluse
class HistoryViewModel(app: Application) : AndroidViewModel(app) {

    // Repository per accedere ai dati delle partite
    private val repo = GameRepository(MastermindDatabase.get(app).gameDao())

    // Flusso con la lista trasformata in HistoryItem per la UI
    val games: StateFlow<List<HistoryItem>> = repo.finished()
        .map { list ->
            list.map { g ->
                HistoryItem(
                    id = g.id,
                    date = g.date,
                    attempts = g.moves.size,
                    won = g.moves.lastOrNull()?.guess == g.secret,
                    settings = g.settings
                )
            }
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
}
