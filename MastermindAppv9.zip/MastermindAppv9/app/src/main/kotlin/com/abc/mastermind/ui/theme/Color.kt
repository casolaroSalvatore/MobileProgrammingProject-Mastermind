package com.abc.mastermind.ui.theme

import androidx.compose.ui.graphics.Color

// Definizione della palette colori e dei colori di supporto per i componenti dell'app.

/* ---------- Palette principale ---------- */
val md_onPrimary = Color(0xFFFFFFFF)        // Colore per il testo/icona su sfondo primario (bianco)

/* ---------- Contorni e feedback dei peg ---------- */
val PegBorder = Color(0x40000000)        // Nero al 25% di opacità (outline dei peg)
val PegFeedback = Color(0xFF616161)        // Grigio scuro (feedback)
val PegBorder1 =
    Color(0x405D4037)        // Marrone scuro trasparente (altro tipo di bordo/feedback)
