package com.abc.mastermind.ui.component

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.abc.mastermind.domain.model.ColorPeg

// Composable che disegna un peg (cerchio) colorato con ombra leggera.
// Utilizzato per rappresentare i pallini del gioco.
@Composable
fun Peg(
    color: ColorPeg,           // Il colore del peg (usato per calcolare l'ARGB)
    size: Int = 28             // Dimensione del peg in dp (default 28)
) = Box(
    Modifier
        .size(size.dp)
        .shadow(4.dp, CircleShape, clip = false)
        .clip(CircleShape)
        .background(Color(color.argb))
)
