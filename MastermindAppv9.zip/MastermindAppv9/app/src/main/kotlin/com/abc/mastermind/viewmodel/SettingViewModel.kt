package com.abc.mastermind.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.abc.mastermind.data.preferences.PreferencesManager
import com.abc.mastermind.internationalization.LocaleManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*

// ViewModel per lo screen delle impostazioni.
// Espone le preferenze audio e lingua come StateFlow e fornisce metodi per modificarle.
class SettingViewModel(app: Application) : AndroidViewModel(app) {

    private val pref = PreferencesManager(app)

    /* ---------- AUDIO ---------- */

    // Volume musica (flow con stato iniziale di fallback 0.8f)
    val musicVolume: StateFlow<Float> = pref.floatFlow("music_vol", 0.8f)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.8f)

    // Volume effetti sonori (flow con stato iniziale di fallback 1.0f)
    val sfxVolume: StateFlow<Float> = pref.floatFlow("sfx_vol", 1.0f)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 1.0f)

    // Imposta volume musica (con clamp 0..1)
    fun setMusicVolume(v: Float) = viewModelScope.launch {
        pref.setFloat("music_vol", v.coerceIn(0f, 1f))
    }

    // Imposta volume effetti (con clamp 0..1)
    fun setSfxVolume(v: Float) = viewModelScope.launch {
        pref.setFloat("sfx_vol", v.coerceIn(0f, 1f))
    }

    /* ---------- LINGUA ---------- */

    // Flow del codice lingua corrente
    private val _language = MutableStateFlow(Locale.getDefault().language)
    val language: StateFlow<String> = _language.asStateFlow()

    init {
        // Aggiorna _language quando cambiano le preferenze
        viewModelScope.launch {
            pref.language.collect { _language.value = it }
        }
    }

    // Eventi one-shot per la UI
    private val _uiEvent = MutableSharedFlow<UiEvent>(extraBufferCapacity = 1)
    val uiEvent = _uiEvent.asSharedFlow()

    // Eventi emessi dal ViewModel
    enum class UiEvent { LanguageChanged }

    // Cambia la lingua: aggiorna le preferenze e notifica la UI
    fun setLanguage(code: String) = viewModelScope.launch {
        LocaleManager.change(getApplication(), code) // cambia locale + salva preferenza
        _uiEvent.emit(UiEvent.LanguageChanged)
    }
}
