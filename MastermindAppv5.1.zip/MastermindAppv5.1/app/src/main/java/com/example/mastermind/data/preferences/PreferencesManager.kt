package com.example.mastermind.data.preferences

import android.content.Context
import java.util.Locale
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.example.mastermind.domain.model.GameSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("settings")

class PreferencesManager(private val context: Context) {

    private object Keys {
        val COLORS      = intPreferencesKey("colors")
        val LENGTH      = intPreferencesKey("length")
        val DUPLICATES  = booleanPreferencesKey("duplicates")
        val ATTEMPTS    = intPreferencesKey("attempts")
        val LANGUAGE    = stringPreferencesKey("app_language")
    }

    val settings: Flow<GameSettings> = context.dataStore.data.map { p ->
        GameSettings(
            p[Keys.COLORS] ?: 6,
            p[Keys.LENGTH] ?: 4,
            p[Keys.DUPLICATES] ?: false,
            p[Keys.ATTEMPTS] ?: 9
        )
    }

    suspend fun save(g: GameSettings) = context.dataStore.edit { p ->
        p[Keys.COLORS] = g.colors
        p[Keys.LENGTH] = g.codeLength
        p[Keys.DUPLICATES] = g.allowDuplicates
        p[Keys.ATTEMPTS] = g.maxAttempts
    }

    /* ---------- Flow lingua ---------- */
    val language: Flow<String> = stringFlow(Keys.LANGUAGE, Locale.ENGLISH.language).distinctUntilChanged()                       // <-- NEW evita inutili update

    suspend fun setLanguage(code: String) = setString(Keys.LANGUAGE, code)

    // Funzione per leggere un float
    fun floatFlow(keyName: String, default: Float): Flow<Float> {
        val key = floatPreferencesKey(keyName)
        return context.dataStore.data.map { prefs ->
            prefs[key] ?: default
        }
    }

    // Funzione per salvare un float
    suspend fun setFloat(keyName: String, value: Float) {
        val key = floatPreferencesKey(keyName)
        context.dataStore.edit { prefs ->
            prefs[key] = value
        }
    }

    /* ---------- Helper generici ---------- */
    fun stringFlow(key: Preferences.Key<String>, default: String): Flow<String> =
        context.dataStore.data.map { it[key] ?: default }

    suspend fun setString(key: Preferences.Key<String>, value: String) =
        context.dataStore.edit { it[key] = value }

}
