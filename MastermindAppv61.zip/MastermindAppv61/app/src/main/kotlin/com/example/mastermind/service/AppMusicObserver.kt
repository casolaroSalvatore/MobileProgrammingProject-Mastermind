package com.example.mastermind.service

import android.content.Context
import android.content.Intent
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.*

/* Observer collegato a ProcessLifecycleOwner: avvia la musica quando
   l’app entra in foreground e la ferma quando passa in background.
   Introduce un piccolo ritardo (300 ms) sullo stop, così la musica
   non viene interrotta/ripristinata se l’Activity viene ricreata
   velocemente (es. cambio lingua, rotazione). */

class AppMusicObserver(private val ctx: Context) : DefaultLifecycleObserver {

    /* Job dello stop differito — viene cancellato se l’app torna davanti */
    private var pendingStop: Job? = null

    override fun onStart(owner: LifecycleOwner) {
        // L’app torna visibile --> annulla lo stop e (ri)avvia la musica
        pendingStop?.cancel()
        pendingStop = null
        ctx.startService(Intent(ctx, BackgroundMusicService::class.java))
    }

    override fun onStop(owner: LifecycleOwner) {
        // Nessuna Activity visibile --> programma lo stop tra 300 ms
        pendingStop = CoroutineScope(Dispatchers.Main).launch {
            delay(300)
            ctx.stopService(Intent(ctx, BackgroundMusicService::class.java))
        }
    }
}