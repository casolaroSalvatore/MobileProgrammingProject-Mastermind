package com.example.mastermind.ui.screen

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mastermind.R
import com.example.mastermind.domain.model.ColorPeg
import com.example.mastermind.ui.component.*
import com.example.mastermind.ui.theme.PegBorder1
import com.example.mastermind.ui.theme.md_onPrimary
import com.example.mastermind.viewmodel.GameViewModel
import kotlinx.coroutines.launch

/* Schermata principale di gioco –– graficamente allineata al nuovo stile.  */
@RequiresApi(Build.VERSION_CODES.O)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(nav: NavHostController) {

    /* ------ ViewModel & state ------ */
    val parentEntry = remember(nav) { nav.getBackStackEntry("game_flow") }
    val vm: GameViewModel = viewModel(parentEntry)
    val scope = rememberCoroutineScope()

    val moves      by vm.moves.collectAsState()
    val remaining  by vm.remaining.collectAsState()
    val editing    by vm.editing.collectAsState()
    val canSubmit  by vm.canSubmit.collectAsState(false)
    val settings   by vm.settings.collectAsState()
    val status     by vm.status.collectAsState()
    // val secret     by vm.secretFlow.collectAsState()

    /* ------ Snackbar ------ */
    val snackbarHostState = remember { SnackbarHostState() }
    val hostContent: @Composable (SnackbarHostState) -> Unit = { host ->
        SnackbarHost(host) { data ->
            Snackbar(
                snackbarData   = data,
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor   = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }

    /* ------ dialog flags ------ */
    var askExit      by remember { mutableStateOf(false) }
    var askOverwrite by remember { mutableStateOf(false) }
    val savedMsg   = stringResource(R.string.snackbar_saved)
    val unsaved    by vm.isUnsaved.collectAsState()

    /* ------ listener eventi ------ */
    LaunchedEffect(Unit) {
        vm.uiEvent.collect { ev ->
            when (ev) {
                is GameViewModel.UiEvent.Saved             ->
                    snackbarHostState.showSnackbar(savedMsg)
                is GameViewModel.UiEvent.OverwriteRequired ->
                    askOverwrite = true
                is GameViewModel.UiEvent.Loaded            -> { /* no-op */ }
            }
        }
    }

    /* --------- palette coerente con Menu / Setup --------- */
    val glassBg    = Color.White.copy(alpha = 0.15f)
    val glassShape = RoundedCornerShape(24.dp)

    /* ---------------------------- UI ---------------------------- */
    val landscape = isLandscape()

    WoodBackground {
        Scaffold(
            snackbarHost   = { hostContent(snackbarHostState) },
            containerColor = Color.Transparent,
            topBar = {
                LargeTopAppBar(
                    title = {},
                    navigationIcon = {
                        IconButton(onClick = { askExit = true }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = null, tint = md_onPrimary)
                        }
                    },
                    actions = {
                        if (unsaved) {
                            IconButton(onClick = { scope.launch { vm.saveGame() } }) {
                                Icon(Icons.Default.Save, contentDescription = null, tint = md_onPrimary)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.largeTopAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
            }
        ) { inner ->

            if (landscape) {
                /* ------------------- LANDSCAPE ------------------- */
                Row(
                    Modifier
                        .padding(inner)
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {

                    /* -------- colonna SINISTRA -------- */
                    Column(
                        Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {

                        /* AssistChip(
                            onClick = {}, enabled = false,
                            label   = { Text(secret.joinToString("  ") { it.name }) },
                            colors  = AssistChipDefaults.assistChipColors(
                                disabledContainerColor = glassBg,
                                disabledLabelColor     = md_onPrimary
                            )
                        ) */

                        /* area scorrevole ─ solo se serve */
                        /* ora occupa tutto lo spazio e scrolla solo se servono molti elementi */
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)          // occupa tutto lo spazio verticale
                                .fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(moves.asReversed()) { m ->
                                BoardRow(m.guess, m.blacks, m.whites)
                            }
                        }

                        remaining?.let {
                            AssistChip(
                                onClick = {}, enabled = false,
                                label = { Text(stringResource(R.string.remaining_compatible, it)) },
                                colors = AssistChipDefaults.assistChipColors(
                                    disabledContainerColor = glassBg,
                                    disabledLabelColor = md_onPrimary
                                )
                            )
                        }
                    }

                    /* -------- colonna DESTRA -------- */
                    Column(
                        Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {

                        GuessEditor(
                            current = editing,
                            palette = ColorPeg.subset(settings.colors),
                            allowDuplicates = settings.allowDuplicates,
                            onChange = { l -> l.forEachIndexed { i, c -> vm.updatePeg(i, c) } },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            MenuButton(
                                label = stringResource(R.string.btn_submit),
                                textColor = md_onPrimary,
                                backgroundColor = glassBg,
                                shape = glassShape,
                                enabled = canSubmit,
                                onClick = vm::commitGuess,
                                modifier = Modifier.weight(1f).height(56.dp)
                            )
                            MenuButton(
                                label = stringResource(R.string.btn_clear),
                                textColor = md_onPrimary,
                                backgroundColor = glassBg,
                                shape = glassShape,
                                onClick = { vm.clearEditing() },
                                modifier = Modifier.weight(1f).height(56.dp)
                            )
                        }
                    }
                }
            } else {
                // LAYOUT PORTRAIT: come prima, una colonna
                Column(
                    Modifier
                        .padding(inner)
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Spacer(Modifier.weight(1f))

                    /* AssistChip(
                        onClick = {}, enabled = false,
                        label = { Text(secret.joinToString("  ") { it.name }) },
                        colors = AssistChipDefaults.assistChipColors(
                            disabledContainerColor = glassBg,
                            disabledLabelColor     = md_onPrimary
                        ),
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) */

                    LazyColumn(
                        reverseLayout = true,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp)
                    ) {
                        items(moves) { m ->
                            BoardRow(m.guess, m.blacks, m.whites)
                        }
                    }

                    remaining?.let {
                        AssistChip(
                            onClick = {}, enabled = false,
                            label = { Text(stringResource(R.string.remaining_compatible, it)) },
                            colors = AssistChipDefaults.assistChipColors(
                                disabledContainerColor = glassBg,
                                disabledLabelColor = md_onPrimary
                            ),
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }

                    GuessEditor(
                        current = editing,
                        palette = ColorPeg.subset(settings.colors),
                        allowDuplicates = settings.allowDuplicates,
                        onChange = { list -> list.forEachIndexed { i, c -> vm.updatePeg(i, c) } },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MenuButton(
                            label = stringResource(R.string.btn_submit),
                            textColor = md_onPrimary,
                            backgroundColor = glassBg,
                            shape = glassShape,
                            enabled = canSubmit,
                            onClick = vm::commitGuess,
                            modifier = Modifier.weight(1f).height(56.dp)
                        )
                        MenuButton(
                            label = stringResource(R.string.btn_clear),
                            textColor = md_onPrimary,
                            backgroundColor = glassBg,
                            shape = glassShape,
                            onClick = { vm.clearEditing() },
                            modifier = Modifier.weight(1f).height(56.dp)
                        )
                    }
                }
            }

            /* ---- Overlay fine partita ---- */
            EndOverlay(
                status = status,
                onNewGame = { nav.navigate("setup") },
                onBackToMenu = {
                    nav.navigate("menu") { popUpTo("menu") { inclusive = true } }
                }
            )

            if (askOverwrite) {
                AlertDialog(
                    onDismissRequest = { askOverwrite = false },

                    // Titolo serif ExtraBold 28sp, colore md_onPrimary, ombra leggera
                    title = {
                        Text(
                            text = stringResource(R.string.dialog_overwrite_title),
                            modifier = Modifier.fillMaxWidth(),
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 28.sp,
                                color = md_onPrimary,
                                shadow = Shadow(
                                    color = Color.Black.copy(alpha = 0.3f),
                                    offset = Offset(2f, 2f),
                                    blurRadius = 4f
                                )
                            ),
                            textAlign = TextAlign.Center
                        )
                    },

                    // Messaggio in bodyMedium
                    text = {
                        Text(
                            text = stringResource(R.string.dialog_overwrite_msg),
                            style = MaterialTheme.typography.bodyMedium.copy(color = md_onPrimary)
                        )
                    },

                    // Sfondo “glass”
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.90f),

                    confirmButton = {
                        TextButton(
                            onClick = {
                                askOverwrite = false
                                scope.launch { vm.saveGame(overwrite = true) }
                            },
                            colors = ButtonDefaults.textButtonColors(contentColor = md_onPrimary)
                        ) {
                            Text(
                                text = stringResource(R.string.action_overwrite),
                                style = MaterialTheme.typography.labelLarge.copy(color = md_onPrimary)
                            )
                        }
                    },
                    dismissButton = {
                        TextButton(
                            onClick = { askOverwrite = false },
                            colors = ButtonDefaults.textButtonColors(contentColor = md_onPrimary)
                        ) {
                            Text(
                                text = stringResource(android.R.string.cancel),
                                style = MaterialTheme.typography.labelLarge.copy(color = md_onPrimary)
                            )
                        }
                    }
                )
            }

            /* ---- Dialog Exit ---- */
            if (askExit) {
                if (!unsaved) {
                    askExit = false
                    nav.navigate("menu") { popUpTo("menu") { inclusive = true } }
                } else {
                    AlertDialog(
                        onDismissRequest = { askExit = false },

                        title = {
                            Text(
                                text = stringResource(R.string.dialog_exit_title),
                                modifier = Modifier.fillMaxWidth(),
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontFamily = FontFamily.Serif,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 28.sp,
                                    color = md_onPrimary,
                                    shadow = Shadow(
                                        color = Color.Black.copy(alpha = 0.3f),
                                        offset = Offset(2f, 2f),
                                        blurRadius = 4f
                                    )
                                ),
                                textAlign = TextAlign.Center
                            )
                        },

                        text = {
                            Text(
                                text = stringResource(R.string.dialog_exit_message),
                                style = MaterialTheme.typography.bodyMedium.copy(color = md_onPrimary)
                            )
                        },

                        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.90f),

                        confirmButton = {
                            TextButton(
                                onClick = {
                                    vm.saveProgress()
                                    nav.navigate("menu") { popUpTo("menu") { inclusive = true } }
                                },
                                colors = ButtonDefaults.textButtonColors(contentColor = md_onPrimary)
                            ) {
                                Text(
                                    text = stringResource(R.string.dialog_exit_save_exit),
                                    style = MaterialTheme.typography.labelLarge.copy(color = md_onPrimary)
                                )
                            }
                        },
                        dismissButton = {
                            TextButton(
                                onClick = {
                                    vm.abandonWithoutSaving()
                                    nav.navigate("menu") { popUpTo("menu") { inclusive = true } }
                                },
                                colors = ButtonDefaults.textButtonColors(contentColor = md_onPrimary)
                            ) {
                                Text(
                                    text = stringResource(R.string.dialog_exit_exit),
                                    style = MaterialTheme.typography.labelLarge.copy(color = md_onPrimary)
                                )
                            }
                        }
                    )
                }
            }
        }
    }
}
