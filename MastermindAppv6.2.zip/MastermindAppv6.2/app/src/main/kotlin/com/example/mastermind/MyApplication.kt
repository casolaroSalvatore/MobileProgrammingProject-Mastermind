package com.example.mastermind

import android.app.Application
import androidx.lifecycle.ProcessLifecycleOwner
import com.example.mastermind.data.MastermindDatabase
import com.example.mastermind.data.preferences.PreferencesManager
import com.example.mastermind.data.repository.GameRepository
import com.example.mastermind.internationalization.LocaleManager
import com.example.mastermind.service.AppMusicObserver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/* Service-locator + gestione ciclo vita app */
class MyApplication : Application() {

    /* Room DB – singleton pigramente inizializzato. */
    val database by lazy { MastermindDatabase.get(this) }

    /* Repository usato da tutti i ViewModel. */
    val repository by lazy { GameRepository(database.gameDao(), Dispatchers.IO) }

    /* Preferences (DataStore). */
    val prefs by lazy { PreferencesManager(this) }

    override fun onCreate() {
        super.onCreate()

        // Inizializza la lingua salvata nelle preferenze
        CoroutineScope(Dispatchers.Default).launch {
            LocaleManager.init(this@MyApplication)
        }

        // Osserva il ciclo di vita globale per gestire la musica
        ProcessLifecycleOwner.get().lifecycle.addObserver(AppMusicObserver(this))
    }
}
