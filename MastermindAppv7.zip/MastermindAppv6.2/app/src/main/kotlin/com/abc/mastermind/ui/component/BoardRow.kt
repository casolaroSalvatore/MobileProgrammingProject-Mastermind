package com.abc.mastermind.ui.component

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.abc.mastermind.domain.model.ColorPeg
import com.abc.mastermind.ui.theme.PegBorder
import com.abc.mastermind.ui.theme.uiColor

// Composable che rappresenta una riga della board di Mastermind.
// Visualizza la combinazione proposta e i relativi feedback (neri e bianchi).
@Composable
fun BoardRow(
    guess: List<ColorPeg>,              // Combinazione proposta dal giocatore
    blacks: Int,                        // Numero di pallini neri (colore e posizione corretti)
    whites: Int,                        // Numero di pallini bianchi (colore corretto ma posizione errata)
    modifier: Modifier = Modifier       // Modificatore per personalizzare il layout della riga
) {
    Surface(
        modifier = modifier,
        tonalElevation = 1.dp,
        shape = MaterialTheme.shapes.medium
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                guess.forEach {
                    Box(
                        Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(it.uiColor)
                            .border(1.dp, PegBorder, CircleShape)
                    )
                }
            }
            FeedbackDots(blacks, whites, guess.size)
        }
    }
    Spacer(Modifier.height(6.dp))
}

