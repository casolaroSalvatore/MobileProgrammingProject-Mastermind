package com.example.mastermind.viewmodel

import android.app.Application
import android.os.Build
import android.util.Log    // per debugging
import androidx.annotation.RequiresApi
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.mastermind.data.MastermindDatabase
import com.example.mastermind.data.entity.GameEntity
import com.example.mastermind.data.entity.Move
import com.example.mastermind.data.preferences.PreferencesManager
import com.example.mastermind.data.repository.GameRepository
import com.example.mastermind.domain.logic.MastermindSolver
import com.example.mastermind.domain.model.ColorPeg
import com.example.mastermind.domain.model.GameSettings
import com.example.mastermind.domain.model.GameStatus
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDateTime

/* ---------- Modello visualizzato nella UI ---------- */
data class MoveResult(val guess: List<ColorPeg>, val blacks: Int, val whites: Int)

/* ---------- ViewModel principale ---------- */
class GameViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = GameRepository(MastermindDatabase.get(app).gameDao())
    private val pref = PreferencesManager(app)
    private val gson = Gson()

    /* ---- impostazioni correnti ---- */
    private val _settings = MutableStateFlow(GameSettings())
    val settings: StateFlow<GameSettings> = _settings

    /* ---- stato partita ---- */
    private var secret: List<ColorPeg> = emptyList()
    val secretCode: List<ColorPeg> get() = secret // per il debbuing
    private var gameId: Long? = null
    private val MAX_ATTEMPTS = 9

    private var _ongoingGame = MutableStateFlow<GameEntity?>(null)
    val ongoingGame: StateFlow<GameEntity?> = _ongoingGame

    private val _status = MutableStateFlow<GameStatus>(GameStatus.Playing)
    val status: StateFlow<GameStatus> = _status

    private val _moves = MutableStateFlow<List<MoveResult>>(emptyList())
    val moves: StateFlow<List<MoveResult>> = _moves

    private val _remaining = MutableStateFlow<Int?>(null)
    val remaining: StateFlow<Int?> = _remaining

    /* ---- eventi one-shot per la UI (Snackbar, dialog) ---- */
    private val _uiEvent = MutableSharedFlow<UiEvent>()
    val uiEvent = _uiEvent.asSharedFlow()

    /*------ flag: codice creato----*/
    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready

    /* ---- flag: partita nuova? (mostra icona Save) ---- */
    private val _isNewGame = MutableStateFlow(false)
    val showSaveButton: StateFlow<Boolean> = _isNewGame

    /* ---- editor corrente (slot selezionabili) ---- */
    private val _editing = MutableStateFlow<List<ColorPeg?>>(emptyList())
    val editing: StateFlow<List<ColorPeg?>> = _editing

    /* ---- può inviare tentativo? ---- */
    val canSubmit: StateFlow<Boolean> = combine(_editing, _settings) { g, s ->
        g.size == s.codeLength &&
                g.none { it == null } &&
                (s.allowDuplicates || g.filterNotNull().toSet().size == g.size)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    /* ---------------- inizializzazione ---------------- */
    init {

        viewModelScope.launch {
            var first = true
            pref.settings.collect { newPref ->
                _settings.value = newPref
                if (first) {
                    first = false
                    if (!loadOngoing()) startNewGame(newPref)
                }
            }
        }
    }

    /* ---------------- nuova partita ------------------ */
    fun startNewGame(cfg: GameSettings) = viewModelScope.launch {
        _ready.value = false // reset
        pref.save(cfg)                             // persiste le preferenze
        _settings.value = cfg
        startInternal(cfg)
        _ready.value = true
        _isNewGame.value = true // servirà per mostrare l’icona Save
    }

    /* ---------------- setup interno ------------------ */
    private suspend fun startInternal(cfg: GameSettings) {
        gameId?.let { repo.markFinished(it) }     // chiude eventuale partita in corso
        _status.value = GameStatus.Playing

        /* genera codice segreto */
        val palette = ColorPeg.subset(cfg.colors)
        secret = buildList {
            repeat(cfg.codeLength) {
                var next: ColorPeg
                do {
                    next = palette.random()
                } while (!cfg.allowDuplicates && next in this)
                add(next)
            }
        }

        /* reset dei flussi UI */
        _moves.value      = emptyList()
        _editing.value    = List(cfg.codeLength) { null }
        _remaining.value  = null

        /* salva nel DB come partita "ongoing" */
        gameId = repo.save(
            GameEntity(
                id           = 0,
                date         = LocalDateTime.now(),
                secret       = secret,
                moves        = emptyList(),
                editing      = emptyList(),
                settingsJson = gson.toJson(cfg),
                ongoing      = true
            )
        )
    }

    /* ---------------- caricamento salvataggi ---------------- */
    suspend fun loadOngoing(): Boolean {
        val g = repo.ongoing() ?: return false
        gameId          = g.id
        secret          = g.secret
        _settings.value = gson.fromJson(g.settingsJson, GameSettings::class.java)

        _moves.value = g.moves.map { MoveResult(it.guess, it.blacks, it.whites) }
        _remaining.value = MastermindSolver.remainingCompatible(
            _settings.value,
            _moves.value.map { it.guess to (it.blacks to it.whites) }
        )
        _editing.value  = List(_settings.value.codeLength) { null }
        _status.value   = GameStatus.Playing
        _isNewGame.value = false
        _uiEvent.emit(UiEvent.Loaded)
        return true
    }

    /* ---------------- salvataggio manuale ---------------- */
    suspend fun saveGame(overwrite: Boolean = false, notify: Boolean = true, markNotNew: Boolean = true ) {
        val old = repo.ongoing()
        if (old != null && !overwrite) {
            _uiEvent.emit(UiEvent.OverwriteRequired)
            return
        }

        val idPrev = old?.id ?: gameId ?: 0L
        gameId = repo.save(
            GameEntity(
                id           = idPrev,
                date         = LocalDateTime.now(),
                secret       = secret,
                moves        = _moves.value.map { Move(it.guess, it.blacks, it.whites) },
                editing      = _editing.value.filterNotNull(),
                settingsJson = gson.toJson(_settings.value),
                ongoing      = true
            )
        )
        if (markNotNew) _isNewGame.value = false
        if (notify) _uiEvent.emit(UiEvent.Saved)

    }

    /* ---------------- helper per altre screen ------------- */
    suspend fun getOngoingGameOnce(): GameEntity? = repo.ongoing()
    suspend fun getOngoingSummary(): GameEntity? = repo.ongoing()

    fun discardOngoing(id: Long) = viewModelScope.launch { repo.markFinished(id) }

    /* ---------------- salvataggio automatico / abbandono --- */
    fun saveProgress() = viewModelScope.launch {
        saveGame(overwrite = true)

    }

    fun abandonWithoutSaving() = viewModelScope.launch {
        gameId?.let { repo.markFinished(it) }
        _isNewGame.value = false
    }

    /* ---------------- editor ------------------------------ */
    fun updatePeg(index: Int, color: ColorPeg?) =
        _editing.update { it.toMutableList().also { l -> l[index] = color } }

    /* ---------------- consente di ripulire la sequenza -------- */
    fun clearEditing() {
        _editing.value = List(_settings.value.codeLength) { null }
    }

    /* ---------------- commit di un tentativo -------------- */
    @RequiresApi(Build.VERSION_CODES.O)
    fun commitGuess() {
        val guess = _editing.value.filterNotNull()
        val cfg   = _settings.value
        if (guess.size != cfg.codeLength) return

        viewModelScope.launch {
            val (b, w) = MastermindSolver.feedback(secret, guess)
            _moves.update { it + MoveResult(guess, b, w) }

            _remaining.value = MastermindSolver.remainingCompatible(
                cfg,
                _moves.value.map { it.guess to (it.blacks to it.whites) }
            )

            _editing.value = List(cfg.codeLength) { null }  // reset editor
            saveGame(overwrite = true, notify = false, markNotNew = false) // autosave

            when {
                b == secret.size -> {
                    repo.markFinished(gameId!!)
                    _status.value = GameStatus.Won
                }
                _moves.value.size >= MAX_ATTEMPTS -> {
                    repo.markFinished(gameId!!)
                    _status.value = GameStatus.Lost(secret)
                }
            }
            printAllGames()

        }

    }
    /*-------- controlla se ci sono partite in corso ---------*/
    suspend fun ongoing(): GameEntity? = repo.ongoing()







    /* True se la partita è ancora in corso (player può salvare o fare guess). */
    fun isPlaying(): Boolean = _status.value is GameStatus.Playing

    /* ---------------- sealed UiEvent --------------------- */
    sealed interface UiEvent {
        object Saved            : UiEvent
        object OverwriteRequired: UiEvent
        object Loaded           : UiEvent
    }





    suspend fun printAllGames() {
        val games = repo.getAllGames()  // aggiungi questa in repo/dao
        games.forEach {
            Log.d("DEBUG", "Game id=${it.id}, ongoing=${it.ongoing}, date=${it.date}")
        }
    }
}






