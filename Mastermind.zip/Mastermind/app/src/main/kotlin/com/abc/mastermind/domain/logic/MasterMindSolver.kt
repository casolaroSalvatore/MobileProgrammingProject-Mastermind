package com.abc.mastermind.domain.logic

import com.abc.mastermind.domain.model.ColorPeg
import com.abc.mastermind.domain.model.GameSettings

// Contiene la logica del gioco Mastermind: calcolo del feedback e verifica delle combinazioni compatibili.
object MastermindSolver {

    // Calcola il numero di pallini neri (posizione e colore corretti)
    // e bianchi (colore corretto ma posizione sbagliata) tra la combinazione segreta e il tentativo.
    fun feedback(secret: List<ColorPeg>, guess: List<ColorPeg>): Pair<Int, Int> {
        require(secret.size == guess.size) // Verifica che le due liste abbiano la stessa lunghezza

        // Conta i pallini neri (posizione e colore corretti)
        val blacks = secret.indices.count { secret[it] == guess[it] }

        // Conta le occorrenze di ogni colore nella segreta e nel tentativo
        val secretCounts = secret.groupingBy { it }.eachCount()
        val guessCounts = guess.groupingBy { it }.eachCount()

        // Somma i minimi tra le occorrenze di ogni colore per determinare i colori in comune
        val common = secretCounts.keys.sumOf { k ->
            minOf(secretCounts[k] ?: 0, guessCounts[k] ?: 0)
        }

        // Calcola i bianchi sottraendo i neri dai comuni
        val whites = (common - blacks).coerceAtLeast(0)
        return blacks to whites
    }

    // Conta il numero di combinazioni ancora compatibili con la storia delle mosse e feedback ricevuti.
    fun remainingCompatible(
        settings: GameSettings,
        history: List<Pair<List<ColorPeg>, Pair<Int, Int>>>
    ): Int {
        val colors = ColorPeg.subset(settings.colors) // Lista dei colori disponibili

        // Se non sono ammessi duplicati ma ci sono meno colori della lunghezza del codice, nessuna combinazione è valida
        if (!settings.allowDuplicates && settings.colors < settings.codeLength)
            return 0

        // Genera tutte le combinazioni possibili, tenendo conto delle impostazioni
        fun codes(): Sequence<List<ColorPeg>> = sequence {
            val idx = IntArray(settings.codeLength)
            val last = colors.size - 1
            while (true) {
                yield(idx.map { colors[it] })
                var p = settings.codeLength - 1
                while (p >= 0 && idx[p] == last) {
                    idx[p] = 0
                    p--
                }
                if (p < 0) break
                idx[p]++
            }
        }.filter { settings.allowDuplicates || it.toSet().size == it.size }

        // Conta le combinazioni compatibili con tutta la cronologia delle mosse
        return codes().count { code ->
            history.all { (g, fb) -> feedback(code, g) == fb }
        }
    }
}
