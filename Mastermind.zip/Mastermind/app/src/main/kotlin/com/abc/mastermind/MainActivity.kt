package com.abc.mastermind

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.abc.mastermind.data.entity.GameEntity
import com.abc.mastermind.service.BackgroundMusicService
import com.abc.mastermind.ui.component.ResumePromptDialog
import com.abc.mastermind.ui.component.WoodBackground
import com.abc.mastermind.ui.screen.*
import com.abc.mastermind.ui.theme.MastermindTheme
import com.abc.mastermind.viewmodel.GameViewModel

/*
  Entry-point dell’app:
    1) Imposta il tema e lo sfondo
    2) Avvia la musica di sottofondo
    3) Definisce il NavHost con tutte le destinazioni (schermate + dialog)
*/

class MainActivity : AppCompatActivity() {

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Avvia la musica di sottofondo quando l'app viene creata
        startService(Intent(this, BackgroundMusicService::class.java))

        setContent {
            MastermindTheme {
                WoodBackground {
                    val nav = rememberNavController()

                    // NavHost con le destinazioni dell'app
                    NavHost(navController = nav, startDestination = "menu") {

                        /* ---------------- Flusso di gioco (setup + partita) ---------------- */
                        navigation(
                            route = "game_flow",
                            startDestination = "setup"
                        ) {
                            composable("setup") { GameSetupScreen(nav) }
                            composable("game") { GameScreen(nav) }
                        }

                        /* ---------------- Schermate principali ---------------- */
                        composable("menu") { MenuScreen(nav) }
                        composable("settings") { SettingScreen(nav) }
                        composable("history") { HistoryScreen(nav) }

                        /* ---------------- Dettaglio partita conclusa ---------------- */
                        composable(
                            route = "historyDetail/{gameId}",
                            arguments = listOf(
                                navArgument("gameId") { type = NavType.LongType }
                            )
                        ) { backStackEntry ->
                            val id = backStackEntry.arguments!!.getLong("gameId")
                            HistoryDetailScreen(gameId = id, nav = nav)
                        }

                        /* ---------------- Dialog resume partita salvata ---------------- */
                        dialog("resumePrompt") {
                            ResumePromptDialogWrapper(nav)
                        }
                    }
                }
            }
        }
    }

    // Ferma la musica di sottofondo quando l'app viene distrutta
    override fun onDestroy() {
        stopService(Intent(this, BackgroundMusicService::class.java))
        super.onDestroy()
    }
}

/*
   Composable che funge da wrapper per il dialog "Resume / New".
   1) Carica la partita in corso (se esiste)
   2) Mostra il dialog per riprendere o iniziare una nuova partita
   3) Se non esiste una partita, chiude automaticamente il dialog
*/

@Composable
private fun ResumePromptDialogWrapper(nav: NavHostController) {
    val vm: GameViewModel = viewModel()

    // Stato per contenere la partita in corso (se esiste)
    var game by remember { mutableStateOf<GameEntity?>(null) }

    // Effetto che viene eseguito una sola volta per caricare la partita
    LaunchedEffect(Unit) {
        game = vm.getOngoingGameOnce()
        if (game == null) {
            // Nessuna partita in corso → chiudi il dialog
            nav.popBackStack()
        }
    }

    // Se la partita esiste, mostra il dialog con le azioni
    game?.let { g ->
        ResumePromptDialog(
            game = g,
            onResume = {
                // Chiude il dialog e naviga alla schermata di gioco
                nav.popBackStack()
                nav.navigate("game")
            },
            onDiscard = {
                // Chiude il dialog e naviga alla schermata di setup
                nav.popBackStack()
                nav.navigate("setup")
            }
        )
    }
}
