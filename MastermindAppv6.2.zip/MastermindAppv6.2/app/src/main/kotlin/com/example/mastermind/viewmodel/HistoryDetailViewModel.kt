package com.example.mastermind.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mastermind.data.entity.GameEntity
import com.example.mastermind.data.repository.GameRepository
import com.example.mastermind.domain.model.ColorPeg
import com.example.mastermind.domain.model.GameSettings
import kotlinx.coroutines.flow.*
import java.time.format.DateTimeFormatter

data class MoveFeedback(
    val guess: List<ColorPeg>,
    val blacks: Int,
    val whites: Int
)

class HistoryDetailViewModel(
    repo: GameRepository,
    gameId: Long
) : ViewModel() {

    private val game: Flow<GameEntity?> = repo.gameById(gameId)

    val rows = game
        .map { it?.moves?.map { m -> MoveFeedback(m.guess, m.blacks, m.whites) } ?: emptyList() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val secret = game
        .map { it?.secret ?: emptyList() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val won = game
        .map { it?.moves?.lastOrNull()?.guess == it?.secret }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val formattedDate = game
        .map { it?.date?.format(DateTimeFormatter.ofPattern("dd MMM yyyy – HH:mm")) ?: "" }
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")

    val settings: StateFlow<GameSettings?> = game
        .map { it?.settings }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)
}