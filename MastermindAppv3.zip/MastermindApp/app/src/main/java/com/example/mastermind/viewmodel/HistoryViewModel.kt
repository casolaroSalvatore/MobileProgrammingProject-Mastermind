package com.example.mastermind.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.mastermind.data.MastermindDatabase
import com.example.mastermind.data.repository.GameRepository
import com.example.mastermind.domain.model.GameSettings
import com.google.gson.Gson
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDateTime

data class HistoryItem(
    val id: Long,
    val date: LocalDateTime,
    val attempts: Int,
    val won: Boolean,
    val settings: GameSettings
)

class HistoryViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = GameRepository(MastermindDatabase.get(app).gameDao())
    private val gson = Gson()

    val games = repo.finished()
        .map { list ->
            list.map { g ->
                val s = gson.fromJson(g.settingsJson, GameSettings::class.java)
                HistoryItem(
                    id       = g.id,
                    date     = g.date,
                    attempts = g.moves.size,
                    won      = g.moves.lastOrNull()?.guess == g.secret,
                    settings = s
                )
            }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
}




