package com.example.mastermind

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.mastermind.data.entity.GameEntity
import com.example.mastermind.service.BackgroundMusicService
import com.example.mastermind.ui.component.WoodBackground
import com.example.mastermind.ui.screen.*
import com.example.mastermind.ui.theme.MastermindTheme
import com.example.mastermind.viewmodel.GameViewModel
import kotlinx.coroutines.launch

/* Entry point dell’app: imposta il tema, lo sfondo in legno edefinisce il NavHost con tutte le destinazioni.*/
class MainActivity : AppCompatActivity() {

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /* Musica di sottofondo */
        startService(Intent(this, BackgroundMusicService::class.java))

        val locale = resources.configuration.locales[0]
        Log.d("LOCALE", "ACTIVITY ➜ onCreate, locale=$locale")

        setContent {
            MastermindTheme {
                WoodBackground {
                    val nav = rememberNavController()

                    NavHost(navController = nav, startDestination = "menu") {

                        /* ----------- Schermate principali ----------- */
                        composable("menu")   { MenuScreen(nav) }
                        composable("setup")  { GameSetupScreen(nav) }
                        composable("game")   { GameScreen(nav) }

                        /* ----------- Dialog “Resume / New” ----------- */
                        dialog("resumePrompt") {

                            val vm: GameViewModel = viewModel()
                            var game by remember { mutableStateOf<GameEntity?>(null) }
                            val scope = rememberCoroutineScope()

                            LaunchedEffect(Unit) { game = vm.getOngoingGameOnce() }

                            game?.let { g ->
                                ResumePromptDialog(
                                    game = g,
                                    onResume = {
                                        nav.popBackStack()
                                        nav.navigate("game")
                                    },
                                    onDiscard = {
                                        nav.popBackStack()
                                        nav.navigate("setup")     // Apre lo screen di configurazione
                                    }
                                )
                            } ?: scope.launch { nav.popBackStack() }
                        }

                        /* ----------- Altre schermate ----------- */
                        composable("settings") { SettingScreen(nav) }
                        composable("history")  { HistoryScreen(nav) }

                        composable(
                            "historyDetail/{gameId}",
                            arguments = listOf(navArgument("gameId") {
                                type = NavType.LongType
                            })
                        ) { back ->
                            HistoryDetailScreen(
                                gameId = back.arguments!!.getLong("gameId"),
                                nav = nav
                            )
                        }
                    }
                }
            }
        }
    }
}
