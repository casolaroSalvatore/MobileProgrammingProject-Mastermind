package com.abc.mastermind

import android.app.Application
import androidx.lifecycle.ProcessLifecycleOwner
import com.abc.mastermind.internationalization.LocaleManager
import com.abc.mastermind.service.AppMusicObserver
import com.abc.mastermind.service.SoundManager
import com.example.mastermind.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/*
   Application class dell'app:
   1) Inizializza la lingua all'avvio basandosi sulle preferenze salvate
   2) Collega un observer al ciclo di vita globale dell'app per gestire la musica
*/

class MyApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // Inizializza la lingua salvata nelle preferenze e applica il locale
        CoroutineScope(Dispatchers.Default).launch {
            LocaleManager.init(this@MyApplication)
        }

        // Collega un observer al ciclo di vita del processo per gestire
        // automaticamente la musica di sottofondo (start/stop)
        ProcessLifecycleOwner.get().lifecycle.addObserver(AppMusicObserver(this))

        // Inizializza SoundManager
        SoundManager.init(this, R.raw.click_sound)
    }

    override fun onTerminate() {
        SoundManager.release()
        super.onTerminate()
    }
}
