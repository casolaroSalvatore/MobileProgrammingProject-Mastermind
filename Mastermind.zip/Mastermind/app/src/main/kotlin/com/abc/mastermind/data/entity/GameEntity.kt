package com.abc.mastermind.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.abc.mastermind.domain.model.ColorPeg
import com.abc.mastermind.domain.model.GameSettings
import com.abc.mastermind.data.util.Converters
import java.time.LocalDateTime

// Entità Room che rappresenta una partita di Mastermind salvata nel database.
// Contiene i dati principali della partita, inclusa la soluzione segreta e lo storico delle mosse.
@Entity(tableName = "game")
@TypeConverters(Converters::class)
data class GameEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,      // ID univoco della partita, generato automaticamente
    val date: LocalDateTime,                                // Data e ora di creazione della partita
    val secret: List<ColorPeg>,                             // Combinazione segreta da indovinare
    val moves: List<Move>,                                  // Storico delle mosse effettuate
    val editing: List<ColorPeg> = emptyList(),              // Stato corrente della combinazione che l'utente sta editando
    val settings: GameSettings,                             // Impostazioni della partita (es. numero colori, lunghezza codice)
    val ongoing: Boolean = true                             // Flag che indica se la partita è ancora in corso
)
