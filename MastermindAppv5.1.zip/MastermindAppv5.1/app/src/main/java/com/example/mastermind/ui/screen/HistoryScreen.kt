package com.example.mastermind.ui.screen

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mastermind.R
import com.example.mastermind.ui.component.WoodBackground
import com.example.mastermind.ui.theme.PegBorder1
import com.example.mastermind.ui.theme.md_onPrimary
import com.example.mastermind.viewmodel.HistoryViewModel
import java.time.format.DateTimeFormatter

/* Lista delle partite concluse. Tapping su un item porta a HistoryDetailScreen. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(nav: NavHostController) {

    val vm: HistoryViewModel = viewModel()
    val list by vm.games.collectAsState()

    val fmt = remember {
        DateTimeFormatter.ofPattern("dd MMM yyyy – HH:mm")
    }

    WoodBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {} // TopAppBar rimossa
        ) { inner ->
            Column(
                modifier = Modifier
                    .padding(inner)
                    .fillMaxSize()
            ) {
                // ICONA INDIETRO
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(start = 8.dp, top = 8.dp)
                ) {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                }

                // SPAZIO TRA ICONA E BOX
                Spacer(modifier = Modifier.height(8.dp))

                // BOX CON IL TITOLO
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .border(
                            width = 2.dp,
                            color = PegBorder1,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(vertical = 16.dp, horizontal = 16.dp)
                ) {
                    Text(
                        text = stringResource(R.string.title_history),
                        modifier = Modifier.fillMaxWidth(),
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 28.sp,
                            fontFamily = FontFamily.Serif,
                            color = md_onPrimary,
                            shadow = Shadow(
                                color = Color.Black.copy(alpha = 0.3f),
                                offset = Offset(2f, 2f),
                                blurRadius = 4f
                            )
                        ),
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(12.dp)) // Spazio tra box e lista

                if (list.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(stringResource(R.string.history_empty))
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .padding(horizontal = 8.dp)
                            .fillMaxSize()
                    ) {
                        items(
                            items = list,
                            key = { it.id }
                        ) { h ->
                            ListItem(
                                headlineContent = { Text(h.date.format(fmt)) },
                                supportingContent = {
                                    Text(
                                        stringResource(
                                            R.string.history_item_fmt,
                                            h.attempts,
                                            h.settings.colors,
                                            if (h.won) stringResource(R.string.history_win) else stringResource(R.string.history_lose)
                                        )
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        nav.navigate("historyDetail/${h.id}")
                                    }
                            )
                            Divider()
                        }
                    }
                }
            }
        }
    }
}