package com.abc.mastermind.ui.screen

import android.view.Gravity
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mastermind.R
import com.abc.mastermind.data.entity.GameEntity
import com.abc.mastermind.domain.model.ColorPeg
import com.abc.mastermind.ui.component.MenuButton
import com.abc.mastermind.ui.component.Peg
import com.abc.mastermind.ui.component.ResumePromptDialog
import com.abc.mastermind.ui.component.isLandscape
import com.abc.mastermind.ui.theme.md_onPrimary
import com.abc.mastermind.viewmodel.GameViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Schermata principale del menu dell'app: mostra pulsanti per nuova partita, riprendi, cronologia.
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuScreen(nav: NavHostController) {

    // ViewModel e coroutine scope
    val vm: GameViewModel = viewModel()
    val scope = rememberCoroutineScope()

    // Stato per partita in corso (async)
    val ongoing by produceState<GameEntity?>(initialValue = null) {
        value = vm.getOngoingSummary()
    }

    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    var savedGame by remember { mutableStateOf<GameEntity?>(null) }
    var showDlg by remember { mutableStateOf(false) }

    // Contenuto snackbar
    val hostContent: @Composable (SnackbarHostState) -> Unit = { host ->
        SnackbarHost(host) { data ->
            Snackbar(
                snackbarData = data,
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }

    // Dialog per riprendere o iniziare nuova partita
    savedGame?.let { g ->
        if (showDlg) {
            ResumePromptDialog(
                game = g,
                onResume = {
                    showDlg = false
                    scope.launch { vm.loadOngoing() }
                    nav.navigate("game")
                },
                onDiscard = {
                    showDlg = false
                    nav.navigate("setup")
                }
            )
        }
    }

    val background = painterResource(id = R.drawable.wood_background)
    val landscape = isLandscape()

    Box(Modifier.fillMaxSize()) {

        // Sfondo legno
        Image(
            painter = background,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Scaffold(
            snackbarHost = { hostContent(snackbarHostState) },
            containerColor = Color.Transparent,
            topBar = {
                SmallTopAppBar(
                    title = {},
                    actions = {
                        IconButton(onClick = { nav.navigate("settings") }) {
                            Icon(
                                Icons.Default.Settings,
                                contentDescription = null,
                                tint = md_onPrimary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = Color.Transparent)
                )
            }
        ) { inner ->

            Column(
                modifier = Modifier
                    .padding(inner)
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                // Titolo principale
                Text(
                    text = stringResource(R.string.app_name).uppercase(),
                    style = TextStyle(
                        color = md_onPrimary,
                        fontSize = 46.sp,
                        fontWeight = FontWeight.ExtraBold,
                        shadow = Shadow(
                            color = Color.Black.copy(alpha = 0.35f),
                            offset = Offset(4f, 4f),
                            blurRadius = 8f
                        ),
                        letterSpacing = 2.sp,
                        textAlign = TextAlign.Center
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 24.dp, bottom = if (landscape) 40.dp else 64.dp)
                )

                if (landscape) {
                    // LANDSCAPE: pulsanti in riga
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(24.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 32.dp)
                    ) {
                        MenuButton(
                            label = stringResource(R.string.menu_start_new),
                            icon = Icons.Default.PlayArrow,
                            onClick = {
                                scope.launch {
                                    savedGame =
                                        withContext(Dispatchers.IO) { vm.getOngoingSummary() }
                                    if (savedGame != null) showDlg = true else nav.navigate("setup")
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(72.dp)
                        )
                        MenuButton(
                            label = stringResource(R.string.menu_resume),
                            icon = Icons.Default.Storage,
                            onClick = {
                                if (ongoing != null) {
                                    scope.launch { vm.loadOngoing(); nav.navigate("game") }
                                } else {
                                    Toast.makeText(
                                        context,
                                        context.getString(R.string.no_saved_game),
                                        Toast.LENGTH_SHORT
                                    ).apply {
                                        setGravity(
                                            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL,
                                            0,
                                            (64 * context.resources.displayMetrics.density).toInt()
                                        )
                                    }.show()
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(72.dp)
                                .alpha(if (ongoing != null) 1f else 0.5f)
                        )
                        MenuButton(
                            label = stringResource(R.string.title_history),
                            icon = Icons.Default.History,
                            onClick = { nav.navigate("history") },
                            modifier = Modifier
                                .weight(1f)
                                .height(72.dp)
                        )
                    }
                } else {
                    // PORTRAIT: pulsanti in colonna
                    val btnWidth = 0.9f

                    MenuButton(
                        label = stringResource(R.string.menu_start_new),
                        icon = Icons.Default.PlayArrow,
                        onClick = {
                            scope.launch {
                                savedGame = withContext(Dispatchers.IO) { vm.getOngoingSummary() }
                                if (savedGame != null) showDlg = true else nav.navigate("setup")
                            }
                        },
                        textStyle = MaterialTheme.typography.titleMedium,
                        modifier = Modifier
                            .fillMaxWidth(btnWidth)
                            .height(100.dp)
                            .padding(vertical = 16.dp)
                    )
                    MenuButton(
                        label = stringResource(R.string.menu_resume),
                        icon = Icons.Default.Storage,
                        onClick = {
                            if (ongoing != null) {
                                scope.launch { vm.loadOngoing(); nav.navigate("game") }
                            } else {
                                Toast.makeText(
                                    context,
                                    context.getString(R.string.no_saved_game),
                                    Toast.LENGTH_SHORT
                                ).apply {
                                    setGravity(
                                        Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL,
                                        0,
                                        (64 * context.resources.displayMetrics.density).toInt()
                                    )
                                }.show()
                            }
                        },
                        textStyle = MaterialTheme.typography.titleMedium,
                        modifier = Modifier
                            .fillMaxWidth(btnWidth)
                            .height(100.dp)
                            .alpha(if (ongoing != null) 1f else 0.5f)
                            .padding(vertical = 16.dp)
                    )
                    MenuButton(
                        label = stringResource(R.string.title_history),
                        icon = Icons.Default.History,
                        onClick = { nav.navigate("history") },
                        textStyle = MaterialTheme.typography.titleMedium,
                        modifier = Modifier
                            .fillMaxWidth(btnWidth)
                            .height(100.dp)
                            .padding(vertical = 16.dp)
                    )
                }

                // Spazio inferiore e immagine applicazione

                if (!landscape) {
                    Spacer(Modifier.weight(1f))
                    Image(
                        painter = painterResource(id = R.drawable.icon_mastermind),
                        contentDescription = "Decorative Logo",
                        modifier = Modifier
                            .padding(bottom = 48.dp)
                            .size(200.dp)
                            .align(Alignment.CenterHorizontally),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}
