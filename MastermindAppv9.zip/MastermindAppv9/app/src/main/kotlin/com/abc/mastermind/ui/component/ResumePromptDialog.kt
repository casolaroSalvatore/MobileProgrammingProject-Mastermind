package com.abc.mastermind.ui.component

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import com.example.mastermind.R
import com.abc.mastermind.data.entity.GameEntity
import com.abc.mastermind.ui.theme.md_onPrimary
import java.time.format.DateTimeFormatter

// Dialog che chiede all'utente se vuole riprendere una partita salvata
// o iniziarne una nuova. Il background è già disegnato dallo Screen ospitante.
@Composable
fun ResumePromptDialog(
    game: GameEntity,                   // Partita salvata da riprendere o scartare
    onResume: () -> Unit,               // Callback quando l'utente sceglie di riprendere la partita
    onDiscard: () -> Unit               // Callback quando l'utente sceglie di iniziare una nuova partita
) {
    val fmt = DateTimeFormatter.ofPattern("dd MMM yyyy – HH:mm")
    // Messaggio con numero mosse e data formattata
    val msg = stringResource(
        R.string.dialog_resume_message,
        game.moves.size,
        game.date.format(fmt)
    )

    AlertDialog(
        onDismissRequest = {}, // Dialog non chiudibile cliccando fuori

        // Titolo del dialog, con stile serifato ed extra bold
        title = {
            Text(
                text = stringResource(R.string.dialog_resume_title),
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 28.sp,
                    color = md_onPrimary,
                    shadow = Shadow(
                        color = Color.Black.copy(alpha = .3f),
                        offset = Offset(2f, 2f),
                        blurRadius = 4f
                    )
                ),
                textAlign = TextAlign.Center
            )
        },

        // Testo principale del dialog
        text = {
            Text(
                text = msg,
                style = MaterialTheme.typography.bodyMedium.copy(color = md_onPrimary)
            )
        },

        // Colore di sfondo semi-trasparente
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .90f),

        // Pulsante per riprendere la partita
        confirmButton = {
            TextButton(
                onClick = onResume,
                colors = ButtonDefaults.textButtonColors(contentColor = md_onPrimary)
            ) {
                Text(
                    text = stringResource(R.string.dialog_resume_resume),
                    style = MaterialTheme.typography.labelLarge.copy(color = md_onPrimary)
                )
            }
        },

        // Pulsante per iniziare una nuova partita
        dismissButton = {
            TextButton(
                onClick = onDiscard,
                colors = ButtonDefaults.textButtonColors(contentColor = md_onPrimary)
            ) {
                Text(
                    text = stringResource(R.string.dialog_resume_new),
                    style = MaterialTheme.typography.labelLarge.copy(color = md_onPrimary)
                )
            }
        }
    )
}
