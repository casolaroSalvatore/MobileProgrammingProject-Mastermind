package com.example.mastermind.domain.model

// Ogni colore porta con sé il proprio valore ARGB (32 bit) usato da Jetpack Compose.

enum class ColorPeg(val argb: Int) {
    RED     (0xFFFF0000.toInt()),
    GREEN   (0xFF4CAF50.toInt()),
    BLUE    (0xFF2196F3.toInt()),
    YELLOW  (0xFFFFEB3B.toInt()),
    ORANGE  (0xFFFF9800.toInt()),
    PURPLE  (0xFF9C27B0.toInt()),
    CYAN    (0xFF00BCD4.toInt()),
    MAGENTA (0xFFE91E63.toInt()),
    BROWN   (0xFF795548.toInt()),
    BLACK   (0xFF000000.toInt());

    companion object {
        /* Restituisce esattamente i primi `n` colori (1 ≤ n ≤ values().size). */
        fun subset(n: Int): List<ColorPeg> {
            require(n in 1..ColorPeg.entries.size) {
                "n must be between 1 and ${ColorPeg.entries.size}"
            }
            return values().take(n)
        }
    }
}

