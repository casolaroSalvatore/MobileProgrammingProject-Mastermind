package com.example.mastermind.data.repository

import com.example.mastermind.data.dao.GameDao
import com.example.mastermind.data.entity.GameEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class GameRepository(private val dao: GameDao) {

    /* ---------- query reattive ---------- */
    fun finished(): Flow<List<GameEntity>>      = dao.getAllFinished()
    fun gameById(id: Long): Flow<GameEntity?>   = dao.getById(id)

    /* ---------- query “una tantum” ---------- */
    suspend fun ongoing(): GameEntity?          = dao.getOngoing()
    suspend fun gameByIdOnce(id: Long): GameEntity? = dao.getByIdOnce(id)

    /* ---------- modifica dati -------------- */
    suspend fun save(game: GameEntity): Long =
        withContext(Dispatchers.IO) { dao.insert(game) }

    suspend fun markFinished(id: Long) =
        withContext(Dispatchers.IO) { dao.markFinished(id) }
}


