package com.abc.mastermind.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.google.accompanist.systemuicontroller.rememberSystemUiController

// Tavolozza calda ispirata al legno e all'ambra (modalità chiara)
private val LightColors = lightColorScheme(
    primary = Color(0xFF8D6E63), // Marrone medio (legno)
    onPrimary = Color.White, secondary = Color(0xFFFFB74D), // Ambra chiaro
    onSecondary = Color.Black, background = Color.Transparent, surface = Color.Transparent
)

// Tavolozza calda per modalità scura
private val DarkColors = darkColorScheme(
    primary = Color(0xFFBCAAA4), // Marrone chiaro
    onPrimary = Color.Black, secondary = Color(0xFFFFCC80), // Ambra chiaro
    background = Color.Transparent, surface = Color.Transparent
)

// Rende tutte le surface-like trasparenti per lasciare visibile lo sfondo legno
private fun transparentify(base: ColorScheme) = base.copy(
    surface = Color.Transparent,
    surfaceVariant = Color.Transparent,
    background = Color.Transparent,
    inverseSurface = Color.Transparent
)

// Tema globale dell'applicazione Mastermind
@Composable
fun MastermindTheme(
    darkTheme: Boolean = isSystemInDarkTheme(), // Se usare dark mode (default: sistema)
    dynamicColor: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S, // Se usare dynamic color (solo da Android 12+)
    content: @Composable () -> Unit // Contenuto del tema
) {
    val baseScheme = when {
        dynamicColor -> {
            val ctx = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        }

        darkTheme -> DarkColors
        else -> LightColors
    }

    val scheme = transparentify(baseScheme)

    // Imposta colori barra di stato e navigation bar trasparenti (overlay sul legno)
    rememberSystemUiController().setSystemBarsColor(Color.Transparent, darkIcons = !darkTheme)

    MaterialTheme(
        colorScheme = scheme, typography = Typography(), shapes = Shapes(), content = content
    )
}
