package com.example.mastermind.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mastermind.R
import com.example.mastermind.data.entity.GameEntity
import com.example.mastermind.ui.component.WoodBackground
import com.example.mastermind.viewmodel.GameViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuScreen(nav: NavHostController) {

    val vm: GameViewModel = viewModel()
    val scope             = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val ctx               = LocalContext.current

    /* stato per il dialog Resume/New */
    var savedGame by remember { mutableStateOf<GameEntity?>(null) }
    var showDlg   by remember { mutableStateOf(false) }

    val hostContent: @Composable (SnackbarHostState) -> Unit = { host ->
        SnackbarHost(host) { data ->
            Snackbar(
                snackbarData  = data,
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor   = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }

    /* ----- Dialog Resume/New dentro la Home ----- */
    savedGame?.let { g ->
        if (showDlg) {
            ResumePromptDialog(
                game = g,
                onResume = {
                    showDlg = false
                    scope.launch { vm.loadOngoing() }
                    nav.navigate("game")
                },
                onDiscard = {
                    scope.launch { vm.discardOngoing(g.id) }
                    showDlg = false
                    nav.navigate("setup")
                }
            )
        }
    }

    WoodBackground {
        Scaffold(
            snackbarHost   = { hostContent(snackbarHostState) },
            containerColor = Color.Transparent,
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text(stringResource(R.string.app_name)) }
                )
            }
        ) { inner ->

            Column(
                Modifier.padding(inner).fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                /* --------- START NEW GAME ---------- */
                MenuButton(Icons.Default.PlayArrow, stringResource(R.string.menu_start_new)) {
                    scope.launch {
                        savedGame = withContext(Dispatchers.IO) { vm.getOngoingSummary() }
                        if (savedGame != null) showDlg = true else nav.navigate("setup")
                    }
                }

                /* --------- RESUME ---------- */
                MenuButton(Icons.Default.Storage, stringResource(R.string.menu_resume)) {
                    scope.launch {
                        val loaded = withContext(Dispatchers.IO) { vm.loadOngoing() }
                        if (loaded) nav.navigate("game")
                        else snackbarHostState.showSnackbar(ctx.getString(R.string.no_saved_game))
                    }
                }

                MenuButton(Icons.Default.History, stringResource(R.string.title_history)) {
                    nav.navigate("history")
                }
                MenuButton(Icons.Default.Settings, stringResource(R.string.title_settings)) {
                    nav.navigate("settings")
                }
            }
        }
    }
}

@Composable
private fun MenuButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    ElevatedCard(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth(0.75f)
            .padding(vertical = 8.dp)
    ) {
        Row(
            Modifier
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null)
            Text(label, style = MaterialTheme.typography.titleLarge)
        }
    }
}

