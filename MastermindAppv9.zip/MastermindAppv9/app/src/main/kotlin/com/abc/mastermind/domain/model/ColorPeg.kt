package com.abc.mastermind.domain.model

// Rappresenta i colori utilizzabili nel gioco Mastermind.
// Ogni colore è associato a un valore ARGB a 32 bit, utile per la visualizzazione con Jetpack Compose.
enum class ColorPeg(val argb: Int) {
    RED(0xFFFF0000.toInt()), // Rosso
    GREEN(0xFF4CAF50.toInt()), // Verde
    BLUE(0xFF2196F3.toInt()), // Blu
    YELLOW(0xFFFFEB3B.toInt()), // Giallo
    ORANGE(0xFFFF9800.toInt()), // Arancione
    PURPLE(0xFF9C27B0.toInt()), // Viola
    CYAN(0xFF00BCD4.toInt()), // Ciano
    MAGENTA(0xFFE91E63.toInt()), // Magenta
    BROWN(0xFF795548.toInt()), // Marrone
    BLACK(0xFF000000.toInt()); // Nero

    companion object {
        // Restituisce una lista contenente i primi `n` colori definiti nell'enum.
        // Lancia un'eccezione se `n` non è nell'intervallo valido.
        fun subset(n: Int): List<ColorPeg> {
            require(n in 1..ColorPeg.entries.size) {
                "n must be between 1 and ${ColorPeg.entries.size}"
            }
            return values().take(n)
        }
    }
}
