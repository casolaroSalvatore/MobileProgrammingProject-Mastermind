package com.example.mastermind.ui.screen

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mastermind.R
import com.example.mastermind.ui.component.WoodBackground
import com.example.mastermind.ui.theme.PegBorder1
import com.example.mastermind.ui.theme.md_onPrimary
import com.example.mastermind.viewmodel.HistoryViewModel
import java.time.format.DateTimeFormatter

/* Lista delle partite concluse – tap per il dettaglio */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(nav: NavHostController) {
    /* ----- VM & state ----- */
    val vm: HistoryViewModel = viewModel()
    val games by vm.games.collectAsState()

    val fmt = remember { DateTimeFormatter.ofPattern("dd MMM yyyy – HH:mm") }

    /* ----- UI ----- */
    WoodBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                LargeTopAppBar(
                    title = {
                        Text(
                            text      = stringResource(R.string.title_history), // o history_detail_title
                            modifier  = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            style     = MaterialTheme.typography.headlineLarge.copy(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize   = 42.sp,
                                color      = md_onPrimary,
                                shadow     = Shadow(
                                    color      = Color.Black.copy(alpha = .4f),
                                    offset     = Offset(4f, 4f),
                                    blurRadius = 10f
                                )
                            ),
                            textAlign = TextAlign.Center
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = null, tint = md_onPrimary)
                        }
                    },
                    colors = TopAppBarDefaults.largeTopAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
            }

        ) { inner ->
            if (games.isEmpty()) {
                /* messaggio lista vuota */
                Box(
                    modifier = Modifier
                        .padding(inner)
                        .fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        stringResource(R.string.history_empty),
                        color = md_onPrimary,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .padding(inner)
                        .fillMaxSize()
                        .padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(games, key = { it.id }) { h ->
                        ListItem(
                            headlineContent = {
                                Text(
                                    h.date.format(fmt),
                                    color = md_onPrimary,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            },
                            supportingContent = {
                                Text(
                                    stringResource(
                                        R.string.history_item_fmt,
                                        h.attempts,
                                        h.settings.colors,
                                        if (h.won) stringResource(R.string.history_win)
                                        else stringResource(R.string.history_lose)
                                    ),
                                    color = Color(0xFF8D6E63), // marrone chiaro
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { nav.navigate("historyDetail/${h.id}") }
                        )
                        Divider(color = PegBorder1.copy(alpha = 0.5f))
                    }
                }
            }
        }
    }
}
