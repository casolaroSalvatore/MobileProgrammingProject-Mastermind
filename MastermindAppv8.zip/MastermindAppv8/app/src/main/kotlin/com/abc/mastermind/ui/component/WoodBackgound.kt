package com.abc.mastermind.ui.component

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.mastermind.R

// Composable che disegna lo sfondo in legno a tutta larghezza e altezza,
// e avvolge un contenuto fornito dal chiamante.
@Composable
fun WoodBackground(
    modifier: Modifier = Modifier,        // Modificatore opzionale per personalizzare il Box esterno
    content: @Composable () -> Unit       // Contenuto da mostrare sopra lo sfondo in legno
) = Box(modifier.fillMaxSize()) {
    Image(
        painter        = painterResource(R.drawable.wood_background),
        contentDescription = null,
        modifier       = Modifier.fillMaxSize(),
        contentScale   = ContentScale.Crop
    )
    content()
}
