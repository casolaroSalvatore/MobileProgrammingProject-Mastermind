package com.example.mastermind.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.mastermind.data.MastermindDatabase
import com.example.mastermind.data.repository.GameRepository
import com.example.mastermind.domain.model.GameSettings
import kotlinx.coroutines.flow.*
import java.time.LocalDateTime

data class HistoryItem(
    val id: Long,
    val date: LocalDateTime,
    val attempts: Int,
    val won: Boolean,
    val settings: GameSettings
)

class HistoryViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = GameRepository(MastermindDatabase.get(app).gameDao())

    val games = repo.finished()
        .map { list ->
            list.map { g ->
                HistoryItem(
                    id       = g.id,
                    date     = g.date,
                    attempts = g.moves.size,
                    won      = g.moves.lastOrNull()?.guess == g.secret,
                    settings = g.settings
                )
            }
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
}