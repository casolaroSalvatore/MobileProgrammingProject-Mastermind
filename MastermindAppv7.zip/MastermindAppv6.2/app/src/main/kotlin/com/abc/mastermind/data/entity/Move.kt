package com.abc.mastermind.data.entity

import com.abc.mastermind.domain.model.ColorPeg
import java.io.Serializable

// Rappresenta una singola mossa effettuata durante la partita.
// Contiene la combinazione proposta e il feedback ricevuto (pallini neri e bianchi).
data class Move(
    val guess: List<ColorPeg>,      // Combinazione proposta dal giocatore
    val blacks: Int,                // Numero di pallini neri (colori e posizioni corretti)
    val whites: Int                 // Numero di pallini bianchi (colori corretti ma posizione errata)
) : Serializable                    // Permette la serializzazione della mossa (es. salvataggio, passaggio tra componenti)
