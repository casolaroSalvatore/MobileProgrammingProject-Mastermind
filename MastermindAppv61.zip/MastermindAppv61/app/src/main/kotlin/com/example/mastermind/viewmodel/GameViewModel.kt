package com.example.mastermind.viewmodel

import android.app.Application
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.mastermind.data.MastermindDatabase
import com.example.mastermind.data.entity.GameEntity
import com.example.mastermind.data.entity.Move
import com.example.mastermind.data.preferences.PreferencesManager
import com.example.mastermind.data.repository.GameRepository
import com.example.mastermind.domain.logic.MastermindSolver
import com.example.mastermind.domain.model.ColorPeg
import com.example.mastermind.domain.model.GameSettings
import com.example.mastermind.domain.model.GameStatus
import com.google.gson.Gson
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDateTime

/* ---------- UI-model per la LazyColumn ---------- */
data class MoveResult(val guess: List<ColorPeg>, val blacks: Int, val whites: Int)

/* ---------- ViewModel principale ---------- */
class GameViewModel(app: Application) : AndroidViewModel(app) {

    /* dipendenze */
    private val repo = GameRepository(MastermindDatabase.get(app).gameDao())
    private val pref = PreferencesManager(app)
    private val gson = Gson()

    /* impostazioni correnti */
    private val _settings = MutableStateFlow(GameSettings())
    val settings = _settings.asStateFlow()

    /* stato in corso */
    private var secret: List<ColorPeg> = emptyList()
    private var gameId: Long? = null
    private val MAX_ATTEMPTS = 9

    private val _status = MutableStateFlow<GameStatus>(GameStatus.Playing)
    val status = _status.asStateFlow()

    /* ---- partita non ancora salvata? (serve per dialog e icona) ---- */
    private val _unsaved = MutableStateFlow(false)
    val    isUnsaved: StateFlow<Boolean> = _unsaved
    val showSaveButton: StateFlow<Boolean> =
      _unsaved.combine(_status) { u, s -> u && s is GameStatus.Playing }
       .stateIn(viewModelScope, SharingStarted.Eagerly, false)


    private val _moves = MutableStateFlow<List<MoveResult>>(emptyList())
    val moves = _moves.asStateFlow()

    private val _remaining = MutableStateFlow<Int?>(null)
    val remaining = _remaining.asStateFlow()

    /* editor corrente */
    private val _editing = MutableStateFlow<List<ColorPeg?>>(emptyList())
    val editing = _editing.asStateFlow()

    val canSubmit = combine(_editing, _settings) { g, s ->
        g.size == s.codeLength &&
                g.none { it == null } &&
                (s.allowDuplicates || g.filterNotNull().toSet().size == g.size)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    /* DEBUG: sequenza segreta */
    private val _secretFlow = MutableStateFlow<List<ColorPeg>>(emptyList())
    val secretFlow = _secretFlow.asStateFlow()

    /* eventi one-shot per la UI */
    private val _uiEvent = MutableSharedFlow<UiEvent>()
    val uiEvent = _uiEvent.asSharedFlow()

    /* init: carica preferenze, tenta resume */
    init {
        viewModelScope.launch {
            var first = true
            pref.settings.collect { newPref ->
                _settings.value = newPref
                if (first) {
                    first = false
                    loadOngoing()           // non crea una partita nuova
                }
            }
        }
    }

    /* -------- nuova partita -------- */
    fun startNewGame(cfg: GameSettings) = viewModelScope.launch {
        pref.save(cfg)
        _settings.value = cfg
        startInternal(cfg)
        _unsaved.value = true  // nuova partita non ancora salvata
    }

    /* -------- setup interno -------- */
    private suspend fun startInternal(cfg: GameSettings) {

        if (_unsaved.value) {
            gameId?.let { repo.markFinished(it) }   // segna come conclusa
        }

        _status.value = GameStatus.Playing
        _unsaved.value = true

        /* genera codice segreto */
        val palette = ColorPeg.subset(cfg.colors)
        if (!cfg.allowDuplicates && cfg.colors < cfg.codeLength) {
            throw IllegalArgumentException("Impossible to generate secret code: not enough unique colors")
        }

        secret = buildList {
            repeat(cfg.codeLength) {
                var next: ColorPeg
                do { next = palette.random() }
                while (!cfg.allowDuplicates && contains(next))
                add(next)
            }
        }
        _secretFlow.value = secret

        /* reset UI */
        _moves.value     = emptyList()
        _editing.value   = List(cfg.codeLength) { null }
        _remaining.value = null

        /* crea record DB ma NON ancora riprendibile */
        gameId = repo.save(
            GameEntity(
                id           = 0,
                date         = LocalDateTime.now(),
                secret       = secret,
                moves        = emptyList(),
                editing      = emptyList(),
                settingsJson = gson.toJson(cfg),
                ongoing      = false
            )
        )
    }

    /* -------- load ongoing -------- */
    suspend fun loadOngoing(): Boolean {
        val g = repo.ongoing() ?: return false
        if (!g.ongoing) return false              // ignoriamo partite concluse

        gameId          = g.id
        secret          = g.secret
        _secretFlow.value = secret
        _settings.value = gson.fromJson(g.settingsJson, GameSettings::class.java)

        _moves.value = g.moves.map { MoveResult(it.guess, it.blacks, it.whites) }
        _remaining.value = MastermindSolver.remainingCompatible(
            _settings.value,
            _moves.value.map { it.guess to (it.blacks to it.whites) }
        )
        _editing.value = List(_settings.value.codeLength) { null }
        _status.value  = GameStatus.Playing
        _uiEvent.emit(UiEvent.Loaded)
        return true
    }

    /* -------- saveGame -------- */
    suspend fun saveGame(overwrite: Boolean = false) {
        val old = repo.ongoing()
        if (old != null && !overwrite) {
            _uiEvent.emit(UiEvent.OverwriteRequired)
            return
        }
        val idPrev = old?.id ?: gameId ?: 0L
        val stillPlaying = _status.value is GameStatus.Playing

        gameId = repo.save(
            GameEntity(
                id           = idPrev,
                date         = LocalDateTime.now(),
                secret       = secret,
                moves        = _moves.value.map { Move(it.guess, it.blacks, it.whites) },
                editing      = _editing.value.filterNotNull(),
                settingsJson = gson.toJson(_settings.value),
                ongoing      = stillPlaying
            )
        )
        _uiEvent.emit(UiEvent.Saved)
        _unsaved.value = false
    }

    fun saveProgress() = viewModelScope.launch {
        if (_unsaved.value && _status.value is GameStatus.Playing)
            saveForResume()               // salva come partita riprendibile
    }

    /* -------- editor helpers -------- */
    fun updatePeg(index: Int, color: ColorPeg?) =
        _editing.update { it.toMutableList().also { l -> l[index] = color } }

    fun clearEditing() { _editing.value = List(_settings.value.codeLength) { null } }

    /* -------- commit guess -------- */
    @RequiresApi(Build.VERSION_CODES.O)
    fun commitGuess() {
        val guess = _editing.value.filterNotNull()
        val cfg   = _settings.value
        if (guess.size != cfg.codeLength) return

        viewModelScope.launch {
            val (b, w) = MastermindSolver.feedback(secret, guess)
            _moves.update { it + MoveResult(guess, b, w) }

            _remaining.value = MastermindSolver.remainingCompatible(
                cfg,
                _moves.value.map { it.guess to (it.blacks to it.whites) }
            )

            _editing.value = List(cfg.codeLength) { null }  // reset editor

            val finished = when {
                b == secret.size -> {
                    repo.markFinished(gameId!!)
                    _status.value = GameStatus.Won
                    true
                }
                _moves.value.size >= MAX_ATTEMPTS -> {
                    repo.markFinished(gameId!!)
                    _status.value = GameStatus.Lost(secret)
                    true
                }
                else -> false
            }

            /* salva dopo aver aggiornato lo stato (ongoing coerente) */
            saveHistory() // autosave nello “History” (ongoing=false)
        }
    }

    /* -------- helper per altre screen -------- */
    suspend fun getOngoingSummary(): GameEntity? = repo.ongoing()
    fun discardOngoing(id: Long) = viewModelScope.launch { repo.markFinished(id) }
    suspend fun getOngoingGameOnce(): GameEntity? = repo.ongoing()

    fun isPlaying(): Boolean = _status.value is GameStatus.Playing

    fun abandonWithoutSaving() = viewModelScope.launch {
        gameId?.let { repo.markFinished(it) }
    }

    /* ---- salva solo nello History (ongoing = false, nessun toast) ---- */
    private suspend fun saveHistory() {
        repo.save(
            GameEntity(
                id           = gameId ?: 0L,
                date         = LocalDateTime.now(),
                secret       = secret,
                moves        = _moves.value.map { Move(it.guess, it.blacks, it.whites) },
                editing      = _editing.value.filterNotNull(),
                settingsJson = gson.toJson(_settings.value),
                ongoing      = false
            )
        )
        _unsaved.value = true              // resta ancora da “rendere riprendibile”
    }

    /* ---- salvataggio manuale: diventa riprendibile, toast ---- */
    suspend fun saveForResume() {
        gameId = repo.save(
            GameEntity(
                id           = gameId ?: 0L,
                date         = LocalDateTime.now(),
                secret       = secret,
                moves        = _moves.value.map { Move(it.guess, it.blacks, it.whites) },
                editing      = _editing.value.filterNotNull(),
                settingsJson = gson.toJson(_settings.value),
                ongoing      = true
            )
        )
        _unsaved.value = false
        _uiEvent.emit(UiEvent.Saved)       // attiva il toast
    }

    /* -------- sealed UiEvent -------- */
    sealed interface UiEvent {
        object Saved            : UiEvent
        object OverwriteRequired: UiEvent
        object Loaded           : UiEvent
    }
}
