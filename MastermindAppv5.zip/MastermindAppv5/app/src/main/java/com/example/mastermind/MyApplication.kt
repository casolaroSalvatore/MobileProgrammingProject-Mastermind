package com.example.mastermind

import android.app.Application
import com.example.mastermind.internationalization.LocaleManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        CoroutineScope(Dispatchers.Default).launch {
            LocaleManager.init(this@MyApplication)   // legge DataStore e chiama apply()
        }
    }
}