package com.abc.mastermind.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.abc.mastermind.data.entity.GameEntity
import com.abc.mastermind.data.repository.GameRepository
import com.abc.mastermind.domain.model.ColorPeg
import com.abc.mastermind.domain.model.GameSettings
import kotlinx.coroutines.flow.*
import java.time.format.DateTimeFormatter

// Rappresenta un feedback di una mossa (tentativo + numero di neri/bianchi)
data class MoveFeedback(
    val guess: List<ColorPeg>,
    val blacks: Int,
    val whites: Int
)

// ViewModel per il dettaglio di una partita nella cronologia.
// Espone lo stato osservabile alla UI (mosse, segreto, data formattata, ecc).
class HistoryDetailViewModel(
    repo: GameRepository,
    gameId: Long
) : ViewModel() {

    // Flusso del game caricato dal repository
    private val game: Flow<GameEntity?> = repo.gameById(gameId)

    // Lista delle mosse con feedback, trasformata per la UI
    val rows: StateFlow<List<MoveFeedback>> = game
        .map { it?.moves?.map { m -> MoveFeedback(m.guess, m.blacks, m.whites) } ?: emptyList() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Codice segreto della partita
    val secret: StateFlow<List<ColorPeg>> = game
        .map { it?.secret ?: emptyList() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Data formattata della partita
    val formattedDate: StateFlow<String> = game
        .map { it?.date?.format(DateTimeFormatter.ofPattern("dd MMM yyyy – HH:mm")) ?: "" }
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")

    // Impostazioni della partita
    val settings: StateFlow<GameSettings?> = game
        .map { it?.settings }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)
}
