package com.abc.mastermind.ui.component

import android.content.res.Configuration
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import com.abc.mastermind.domain.model.ColorPeg
import com.abc.mastermind.ui.theme.PegBorder
import com.abc.mastermind.ui.theme.uiColor

// Composable che rappresenta l'editor per comporre un tentativo.
// Mostra i peg editabili e la palette di colori selezionabili.
@Composable
fun GuessEditor(
    current: List<ColorPeg?>,               // Stato attuale della combinazione in editing
    palette: List<ColorPeg>,                // Palette di colori disponibili per la scelta
    allowDuplicates: Boolean,               // True se sono permessi duplicati nella combinazione
    onChange: (List<ColorPeg?>) -> Unit,    // Callback chiamato quando la combinazione viene aggiornata
    modifier: Modifier = Modifier           // Modificatore opzionale per personalizzare l'editor
) {
    var selectedIndex by remember { mutableStateOf<Int?>(null) }

    Column(
        modifier = modifier.animateContentSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        /* ---------- Peg editabili ---------- */
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            current.forEachIndexed { i, peg ->
                Peg(
                    color = peg?.uiColor ?: Color.Transparent,
                    empty = peg == null,
                    selected = i == selectedIndex,
                    onClick = { selectedIndex = i }
                )
            }
        }

        /* ---------- Palette ---------- */
        Spacer(Modifier.height(12.dp))

        val configuration = LocalConfiguration.current
        val isPortrait = configuration.orientation == Configuration.ORIENTATION_PORTRAIT

        val paletteRows = if (isPortrait && palette.size == 10) {
            palette.chunked(5)
        } else {
            listOf(palette)
        }

        paletteRows.forEach { row ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                row.forEach { pegColor ->
                    Box(
                        Modifier
                            .size(32.dp)
                            .shadow(2.dp, CircleShape, clip = false)
                            .clip(CircleShape)
                            .background(pegColor.uiColor)
                            .clickable(enabled = selectedIndex != null) {
                                selectedIndex?.let { idx ->
                                    val list = current.toMutableList()
                                    if (!allowDuplicates && pegColor in list) return@clickable
                                    list[idx] = pegColor
                                    onChange(list)
                                }
                            }
                    )
                }
            }
        }
    }
}


// Composable che rappresenta un singolo peg (cerchio) nell'editor.
@Composable
private fun Peg(
    color: Color,               // Colore del peg
    empty: Boolean,             // True se il peg è vuoto (nessun colore assegnato)
    selected: Boolean,          // True se il peg è attualmente selezionato per modifica
    onClick: () -> Unit         // Callback chiamato quando il peg viene cliccato
) {
    val outline = if (selected) MaterialTheme.colorScheme.primary else PegBorder
    Box(
        modifier = Modifier
            .size(48.dp)
            .border(2.dp, outline, CircleShape)
            .background(color, CircleShape)
            .alpha(if (empty) .15f else 1f)
            .clickable(onClick = onClick)
    )
}

