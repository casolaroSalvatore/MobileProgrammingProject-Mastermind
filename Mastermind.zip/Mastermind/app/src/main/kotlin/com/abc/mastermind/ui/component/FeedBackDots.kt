package com.abc.mastermind.ui.component

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.abc.mastermind.ui.theme.PegFeedback

// Composable che disegna i pallini di feedback di una combinazione (neri e bianchi).
// Visualizza fino al numero massimo previsto dal codice (tipicamente 4 o 5).
@Composable
fun FeedbackDots(
    blacks: Int,        // Numero di pallini neri (posizione e colore corretti)
    whites: Int,        // Numero di pallini bianchi (colore corretto ma posizione errata)
    codeLength: Int     // Lunghezza del codice segreto (serve per calcolare i pallini vuoti)
) {
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        repeat(blacks) {
            Dot(Color.Black)
        }
        repeat(whites) {
            Dot(Color.White, border = PegFeedback)
        }
        repeat(codeLength - blacks - whites) {
            Dot(Color.Transparent)
        }
    }
}

@Composable
private fun Dot(color: Color, border: Color = Color.Transparent) {
    Box(
        modifier = Modifier
            .size(12.dp)
            .shadow(2.dp, CircleShape, clip = false)
            .clip(CircleShape)
            .background(color)
            .border(1.dp, border, CircleShape)
    )
}
