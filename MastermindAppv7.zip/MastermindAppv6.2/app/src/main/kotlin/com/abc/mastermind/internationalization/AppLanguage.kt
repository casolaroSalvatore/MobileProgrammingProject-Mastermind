package com.abc.mastermind.internationalization

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.example.mastermind.R

// Rappresenta una lingua supportata dall'app, con codice, stringa descrittiva e icona della bandiera.
data class AppLanguage(
    val code: String,
    @StringRes val label: Int,
    @DrawableRes val icon: Int
) {
    companion object {
        // Elenco delle lingue supportate dall'applicazione.
        val SUPPORTED = listOf(
            AppLanguage("en", R.string.lang_english, R.drawable.ic_flag_en), // Inglese
            AppLanguage("it", R.string.lang_italian, R.drawable.ic_flag_it), // Italiano
            AppLanguage("es", R.string.lang_spanish, R.drawable.ic_flag_es), // Spagnolo
            AppLanguage("fr", R.string.lang_french, R.drawable.ic_flag_fr),  // Francese
            AppLanguage("de", R.string.lang_german, R.drawable.ic_flag_de)   // Tedesco
        )
    }
}
