package com.abc.mastermind.service

import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.IBinder
import com.example.mastermind.R
import com.abc.mastermind.data.preferences.PreferencesManager
import kotlinx.coroutines.*

// Servizio che gestisce la riproduzione della musica di sottofondo dell'app.
// Avvia un MediaPlayer in loop e sincronizza il volume con le preferenze utente.
class BackgroundMusicService : Service() {

    private lateinit var player: MediaPlayer // MediaPlayer che gestisce la riproduzione della musica
    private val scope =
        CoroutineScope(Dispatchers.Main + SupervisorJob()) // Scope per le coroutine legate al servizio

    override fun onCreate() {
        super.onCreate()

        // Configura il MediaPlayer con gli attributi audio appropriati per un gioco
        player = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .build()
            )
            // Carica il file audio dalla cartella raw
            setDataSource(
                resources.openRawResourceFd(R.raw.background).fileDescriptor,
                resources.openRawResourceFd(R.raw.background).startOffset,
                resources.openRawResourceFd(R.raw.background).length
            )
            // La musica viene riprodotta in loop
            isLooping = true
            prepare()
            start()
        }

        // Sincronizza il volume del player con le preferenze dell'utente
        val pref = PreferencesManager(this)
        scope.launch {
            pref.floatFlow("music_vol", 0.8f).collect { v ->
                player.setVolume(v, v)
            }
        }
    }

    // Il servizio non viene riavviato automaticamente se il sistema lo uccide
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int =
        START_NOT_STICKY

    // Chiamato quando l'app viene chiusa dal task-switcher: arresta il servizio
    override fun onTaskRemoved(rootIntent: Intent?) {
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    // Rilascia le risorse quando il servizio viene distrutto
    override fun onDestroy() {
        player.release()
        scope.cancel()
        super.onDestroy()
    }

    // Il servizio non supporta il binding
    override fun onBind(intent: Intent?): IBinder? = null
}
