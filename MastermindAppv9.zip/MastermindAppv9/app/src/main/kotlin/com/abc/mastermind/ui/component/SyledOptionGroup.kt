package com.abc.mastermind.ui.component

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abc.mastermind.ui.theme.PegBorder1
import com.abc.mastermind.ui.theme.md_onPrimary

// Composable che disegna un gruppo di pulsanti opzione con uno stile personalizzato.
// Ogni pulsante rappresenta un'opzione selezionabile con evidenziazione della selezione.
@Composable
fun StyledOptionGroup(
    label: String,                       // Etichetta descrittiva del gruppo (es. "Modalità")
    options: List<String>,               // Lista di opzioni visualizzate come stringhe
    selected: String,                    // Opzione attualmente selezionata
    onSelect: (String) -> Unit,          // Callback invocata alla selezione di un'opzione
    modifier: Modifier = Modifier        // Modificatore opzionale per personalizzare il layout
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = label,
            color = md_onPrimary,
            style = MaterialTheme.typography.titleMedium
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            options.forEach { option ->
                OutlinedButton(
                    onClick = { onSelect(option) },      // ora OK
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (option == selected)
                            PegBorder1 else Color.White.copy(alpha = 0.1f),
                        contentColor = md_onPrimary
                    ),
                    modifier = Modifier
                        .height(48.dp)
                        .widthIn(min = 46.dp),
                ) { Text(option, fontWeight = FontWeight.Bold, maxLines = 1) }
            }
        }
    }
}
