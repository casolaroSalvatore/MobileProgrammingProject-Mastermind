package com.example.mastermind.ui.screen

import android.app.Activity
import android.util.Log
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mastermind.R
import com.example.mastermind.ui.component.WoodBackground
import com.example.mastermind.viewmodel.SettingViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mastermind.internationalization.AppLanguage
import com.example.mastermind.ui.component.isLandscape
import com.example.mastermind.ui.theme.PegBorder1
import com.example.mastermind.ui.theme.md_onPrimary

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingScreen(nav: NavHostController) {
    val vm: SettingViewModel = viewModel()
    val musicVol by vm.musicVolume.collectAsStateWithLifecycle()
    val sfxVol by vm.sfxVolume.collectAsStateWithLifecycle()
    val langCode by vm.language.collectAsStateWithLifecycle()
    val currentCtx by rememberUpdatedState(LocalContext.current)
    val isLandscape = isLandscape()

    LaunchedEffect(Unit) {
        vm.uiEvent.collect { ev ->
            if (ev == SettingViewModel.UiEvent.LanguageChanged) {
                Log.d("LOCALE", "SCREEN     ➜ recreating activity")
                (currentCtx as? Activity)?.recreate()
            }
        }
    }

    WoodBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                LargeTopAppBar(
                    title = {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                                .border(
                                    width = 2.dp,
                                    color = PegBorder1,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .padding(vertical = 12.dp, horizontal = 16.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.title_settings),
                                modifier = Modifier.fillMaxWidth(),
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 28.sp,
                                    fontFamily = FontFamily.Serif,
                                    color = md_onPrimary,
                                    shadow = Shadow(
                                        color = Color.Black.copy(alpha = 0.3f),
                                        offset = Offset(2f, 2f),
                                        blurRadius = 4f
                                    )
                                ),
                                textAlign = TextAlign.Center
                            )
                        }
                    },
                    navigationIcon = { IconButton({ nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null) } },
                    colors = TopAppBarDefaults.largeTopAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
            }
        ) { innerPadding ->

            if (isLandscape) {
                // Modalità LANDSCAPE
                Column(
                    Modifier
                        .padding(innerPadding)
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Titolo "Audio" centrato sopra i due slider
                    Text(
                        text = stringResource(R.string.section_audio),
                        style = MaterialTheme.typography.titleMedium,
                        textAlign = TextAlign.Center
                    )

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.Top
                    ) {
                        SettingColumnSection(
                            title = stringResource(R.string.music_volume,(musicVol * 100).toInt()),
                            sliderValue = musicVol,
                            onValueChange = vm::setMusicVolume,
                        )
                        SettingColumnSection(
                            title = stringResource(R.string.sfx_volume, (sfxVol * 100).toInt()),
                            sliderValue = sfxVol,
                            onValueChange = vm::setSfxVolume,
                        )
                        LanguageDropdown(
                            currentLangCode = langCode,
                            onLangSelected = {
                                vm.setLanguage(it)
                                (currentCtx as? Activity)?.recreate()
                            }
                        )
                    }
                }
            }    else {
                // Modalità PORTRAIT (rimane come già implementato)
                Column(
                    Modifier
                        .padding(innerPadding)
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {

                    // Sezione AUDIO

                    Text(stringResource(R.string.section_audio),
                        style = MaterialTheme.typography.titleMedium)

                    /* Musica di sottofondo */

                    Text(stringResource(R.string.music_volume, (musicVol * 100).toInt()))
                    Slider(value = musicVol,
                        onValueChange = vm::setMusicVolume,
                        valueRange = 0f..1f)

                    /* Effetti sonori */

                    Text(stringResource(R.string.sfx_volume, (sfxVol * 100).toInt()))
                    Slider(value = sfxVol,
                        onValueChange = vm::setSfxVolume,
                        valueRange = 0f..1f)

                    /* ---------- Lingua ---------- */

                    Text(stringResource(R.string.section_language),
                        style = MaterialTheme.typography.titleMedium)

                    FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp))
                    {
                        AppLanguage.SUPPORTED.forEach { lang ->

                            FilterChip(
                                selected = lang.code == langCode,
                                onClick = {
                                    vm.setLanguage(lang.code)
                                    (currentCtx as? Activity)?.recreate()
                                },
                                label = { Text(stringResource(lang.label)) }
                            )
                        }
                    }
                }
                /* spazio per future impostazioni (tema, vibrazione, …) */
            }
        }
    }
}

@Composable
fun SettingColumnSection(
    title: String,
    sliderValue: Float,
    onValueChange: (Float) -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.widthIn(min = 200.dp, max = 300.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium
        )
        Slider(
            value = sliderValue,
            onValueChange = onValueChange,
            valueRange = 0f..1f
        )
    }
}



@Composable
fun LanguageDropdown(currentLangCode: String, onLangSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }

    val selectedLanguage = AppLanguage.SUPPORTED.first { it.code == currentLangCode }
    val context = LocalContext.current

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(stringResource(R.string.section_language),
            style = MaterialTheme.typography.titleMedium)
        Box {
            OutlinedButton(onClick = { expanded = true }) {
                Text(text = stringResource(selectedLanguage.label))
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                AppLanguage.SUPPORTED.forEach { lang ->
                    DropdownMenuItem(
                        text = { Text(stringResource(lang.label)) },
                        onClick = {
                            expanded = false
                            onLangSelected(lang.code)
                        }
                    )
                }
            }
        }
    }
}
