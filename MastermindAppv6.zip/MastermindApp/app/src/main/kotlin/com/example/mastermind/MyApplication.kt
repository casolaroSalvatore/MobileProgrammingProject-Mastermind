package com.example.mastermind

import android.app.Application
import androidx.lifecycle.ProcessLifecycleOwner
import com.example.mastermind.internationalization.LocaleManager
import com.example.mastermind.service.AppMusicObserver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MyApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // Inizializza la lingua
        CoroutineScope(Dispatchers.Default).launch {
            LocaleManager.init(this@MyApplication)
        }

        // Osserva il ciclo di vita globale dell'app, in particolare per stoppare la musica
        ProcessLifecycleOwner.get().lifecycle.addObserver(AppMusicObserver(this))
    }
}