package com.abc.mastermind.data.util

import androidx.room.TypeConverter
import com.abc.mastermind.data.entity.Move
import com.abc.mastermind.domain.model.ColorPeg
import com.abc.mastermind.domain.model.GameSettings
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

// Classe che fornisce i TypeConverter per Room.
// Converte tipi complessi (es. liste, oggetti, date) in stringhe e viceversa per il salvataggio nel database.
class Converters {

    private val gson = Gson()
    private val fmt: DateTimeFormatter =
        DateTimeFormatter.ISO_LOCAL_DATE_TIME

    // Converte una lista di ColorPeg in una stringa JSON.
    @TypeConverter
    fun colorPegListToJson(list: List<ColorPeg>): String = gson.toJson(list)

    // Converte una stringa JSON in una lista di ColorPeg.
    @TypeConverter
    fun jsonToColorPegList(json: String): List<ColorPeg> =
        gson.fromJson(json, object : TypeToken<List<ColorPeg>>() {}.type)

    // Converte una lista di Move in una stringa JSON.
    @TypeConverter
    fun moveListToJson(list: List<Move>): String = gson.toJson(list)

    // Converte una stringa JSON in una lista di Move.
    @TypeConverter
    fun jsonToMoveList(json: String): List<Move> =
        gson.fromJson(json, object : TypeToken<List<Move>>() {}.type)

    // Converte GameSettings in una stringa JSON.
    @TypeConverter
    fun gameSettingsToJson(s: GameSettings): String = gson.toJson(s)

    // Converte una stringa JSON in GameSettings.
    @TypeConverter
    fun jsonToGameSettings(json: String): GameSettings =
        gson.fromJson(json, GameSettings::class.java)

    // Converte LocalDateTime in una stringa formattata.
    @TypeConverter
    fun localDateTimeToString(t: LocalDateTime): String = fmt.format(t)

    // Converte una stringa formattata in LocalDateTime.
    @TypeConverter
    fun stringToLocalDateTime(s: String): LocalDateTime =
        LocalDateTime.parse(s, fmt)
}
