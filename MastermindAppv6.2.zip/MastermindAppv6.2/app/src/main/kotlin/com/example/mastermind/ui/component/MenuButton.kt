package com.example.mastermind.ui.component

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.mastermind.ui.theme.PegBorder1
import com.example.mastermind.ui.theme.md_onPrimary

@Composable
fun MenuButton(
    label: String,
    textColor: Color = md_onPrimary,
    backgroundColor: Color = PegBorder1,
    icon: ImageVector? = null,
    iconSpacing: Dp = 8.dp,
    shape: RoundedCornerShape = RoundedCornerShape(12.dp),
    enabled: Boolean = true,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    OutlinedButton(
        onClick = onClick,
        enabled  = enabled,
        modifier = modifier,
        shape = shape,
        colors = ButtonDefaults.buttonColors(containerColor = backgroundColor)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = textColor
                )
                if (label.isNotBlank()) {
                    Spacer(modifier = Modifier.width(iconSpacing))
                }

            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = textColor
            )
        }
    }
}

