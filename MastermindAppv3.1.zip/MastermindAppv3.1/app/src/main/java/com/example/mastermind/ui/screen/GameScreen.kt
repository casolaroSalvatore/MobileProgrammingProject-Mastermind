package com.example.mastermind.ui.screen

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mastermind.R
import com.example.mastermind.domain.model.ColorPeg
import com.example.mastermind.ui.component.*
import com.example.mastermind.viewmodel.GameViewModel
import kotlinx.coroutines.launch

/* Schermata principale di gioco.
   Mostra:
   1) storico delle mosse
   2) editor della combinazione corrente
   3) pulsanti submit / clear
   4) FAB + icona di salvataggio
   5) overlay di fine partita
   6) dialog di conferma sovrascrittura e dialog di uscita
*/

@RequiresApi(Build.VERSION_CODES.O)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(nav: NavHostController) {

    /* ------ ViewModel & state ------ */
    val vm: GameViewModel = viewModel()
    val scope             = rememberCoroutineScope()

    val moves      by vm.moves.collectAsState()
    val remaining  by vm.remaining.collectAsState()
    val editing    by vm.editing.collectAsState()
    val canSubmit  by vm.canSubmit.collectAsState(false)
    val settings   by vm.settings.collectAsState()
    val status     by vm.status.collectAsState()

    /* ------ Snackbar ------ */
    val snackbarHostState = remember { SnackbarHostState() }
    val hostContent: @Composable (SnackbarHostState) -> Unit = { host ->
        SnackbarHost(host) { data ->
            Snackbar(
                snackbarData   = data,
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor   = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }

    /* ------ dialog flags ------ */
    var askExit      by remember { mutableStateOf(false) }
    var askOverwrite by remember { mutableStateOf(false) }

    /* ------ listener eventi ------ */
    LaunchedEffect(Unit) {
        vm.uiEvent.collect { ev ->
            when (ev) {
                is GameViewModel.UiEvent.Saved ->
                    snackbarHostState.showSnackbar("Partita salvata!")
                is GameViewModel.UiEvent.OverwriteRequired ->
                    askOverwrite = true
                is GameViewModel.UiEvent.Loaded -> { /* niente */ }
            }
        }
    }

    /* ------ UI ------ */
    WoodBackground {
        Scaffold(
            snackbarHost   = { hostContent(snackbarHostState) },
            containerColor = Color.Transparent,
            topBar = {
                LargeTopAppBar(
                    title = { Text(stringResource(R.string.title_game)) },
                    navigationIcon = {
                        IconButton(onClick = { /*askExit = true*/
                            vm.saveProgress()
                            nav.navigate("menu") }) {
                            Icon(Icons.Default.ArrowBack, null)
                        }
                    },
                    actions = {
                        if (vm.isPlaying()) {                       // <<< mostra solo se partita attiva
                            IconButton(onClick = { scope.launch { vm.saveGame() } }) {
                                Icon(Icons.Default.Save, null)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.largeTopAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
            }
        ) { inner ->
            val listState = rememberLazyListState()
            LaunchedEffect(moves.size) {
                if (moves.isNotEmpty()) {
                    listState.animateScrollToItem(moves.lastIndex)
                }
            }
            /* ---------- BODY ---------- */
            Column(
                Modifier
                    .padding(inner)
                    .fillMaxSize()
                    .padding(16.dp)

            ) {
                Text(   // per il debugging
                text = "Codice segreto: " + vm.secretCode.joinToString(" ") { it.name },
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White,
                modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                Text(    //per il debugging
                    text = "Code length: ${settings.codeLength}, Colors: ${settings.colors}",
                    color = Color.White,
                )
                //Spacer(Modifier.weight(1f))               // spinge tutto in basso
                    /* ---- TENTATIVI (in basso, scroll up) ---- */
                    LazyColumn(
                        state = listState,
                        //reverseLayout = true,
                        verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.Bottom),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        items(moves) { m ->
                            BoardRow(m.guess, m.blacks, m.whites)
                        }
                    }

                /* ---- compatibili rimasti ---- */
                remaining?.let {
                    AssistChip(
                        onClick  = {},
                        enabled  = false,
                        label    = { Text(stringResource(R.string.remaining_compatible, it)) },
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .padding(top = 4.dp, bottom = 8.dp)
                    )
                }

                /* ---- EDITOR ---- */
                GuessEditor(
                    current         = editing,
                    palette         = ColorPeg.subset(settings.colors),
                    allowDuplicates = settings.allowDuplicates,
                    onChange        = { list ->
                        list.forEachIndexed { i, c -> vm.updatePeg(i, c) }
                    },
                    modifier        = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(12.dp))

                /* ---- SUBMIT / CLEAR ---- */
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick  = vm::commitGuess,
                        enabled  = canSubmit,
                        modifier = Modifier.weight(1f)
                    ) { Text(stringResource(R.string.btn_submit)) }

                    FilledTonalButton(
                        onClick  = { vm.clearEditing() },
                        modifier = Modifier.weight(1f)
                    ) { Text(stringResource(R.string.btn_clear)) }
                }
            }

            /* ---- Overlay fine partita ---- */
            EndOverlay(
                status      = status,
                onNewGame   = { nav.navigate("setup") },
                onBackToMenu = {
                    nav.navigate("menu") { popUpTo("menu") { inclusive = true } }
                }
            )

            /* ---- Dialog sovrascrittura ---- */
            if (askOverwrite) {
                AlertDialog(
                    onDismissRequest = { askOverwrite = false },
                    confirmButton = {
                        TextButton(onClick = {
                            askOverwrite = false
                            scope.launch { vm.saveGame(overwrite = true) }
                        }) { Text(stringResource(R.string.action_overwrite)) }
                    },
                    dismissButton = {
                        TextButton(onClick = { askOverwrite = false }) {
                            Text(stringResource(android.R.string.cancel))
                        }
                    },
                    title = { Text(stringResource(R.string.dialog_overwrite_title)) },
                    text  = { Text(stringResource(R.string.dialog_overwrite_msg)) }
                )
            }
        }

        /* ---- Dialog Exit ---- */
        /*if (askExit) {
            AlertDialog(
                onDismissRequest = { askExit = false },
                title = { Text(stringResource(R.string.dialog_exit_title)) },
                text  = { Text(stringResource(R.string.dialog_exit_message)) },
                confirmButton = {
                    TextButton(onClick = {
                        vm.saveProgress()
                        nav.navigate("menu") { popUpTo("menu") { inclusive = true } }
                    }) { Text(stringResource(R.string.dialog_exit_save_exit)) }
                },
                dismissButton = {
                    TextButton(onClick = {
                        vm.abandonWithoutSaving()
                        nav.navigate("menu") { popUpTo("menu") { inclusive = true } }
                    }) { Text(stringResource(R.string.dialog_exit_exit)) }
                },
                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .95f)
            )
        }*/
    }
}







