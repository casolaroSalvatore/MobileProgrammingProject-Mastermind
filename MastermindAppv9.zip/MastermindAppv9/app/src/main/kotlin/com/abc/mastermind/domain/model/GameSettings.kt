package com.abc.mastermind.domain.model

// Rappresenta le impostazioni di una partita di Mastermind.
// Contiene le opzioni configurabili come numero di colori, lunghezza del codice, ecc.
data class GameSettings(
    val colors: Int = 6,                        // Numero di colori disponibili (es. 6, 8, 10)
    val codeLength: Int = 4,                    // Lunghezza della combinazione segreta (tipicamente 4 o 5)
    val allowDuplicates: Boolean = false,       // Indica se sono permessi colori ripetuti nella combinazione
    val maxAttempts: Int = 9                    // Numero massimo di tentativi consentiti
)
