package com.example.mastermind.ui.screen

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import com.example.mastermind.R
import com.example.mastermind.data.entity.GameEntity
import com.example.mastermind.ui.theme.md_onPrimary
import java.time.format.DateTimeFormatter

/* Dialog che chiede se riprendere la partita salvata o iniziarne
   una nuova. Lo sfondo di legno è già disegnato dallo Screen che
   ospita questo composable, quindi il dialog rimane trasparente. */

@Composable
fun ResumePromptDialog(
    game: GameEntity,
    onResume: () -> Unit,
    onDiscard: () -> Unit
) {
    val fmt = DateTimeFormatter.ofPattern("dd MMM yyyy – HH:mm")
    val msg = stringResource(
        R.string.dialog_resume_message,
        game.moves.size,
        game.date.format(fmt)
    )

    AlertDialog(
        onDismissRequest = {},

        // Titolo “serifato”
        title = {
            Text(
                text = stringResource(R.string.dialog_resume_title),
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize   = 28.sp,
                    color      = md_onPrimary,
                    shadow     = Shadow(
                        color      = Color.Black.copy(alpha = .3f),
                        offset     = Offset(2f, 2f),
                        blurRadius = 4f
                    )
                ),
                textAlign = TextAlign.Center
            )
        },

        // Corpo del dialog
        text = {
            Text(
                text = msg,
                style = MaterialTheme.typography.bodyMedium.copy(color = md_onPrimary)
            )
        },

        // Colori di sfondo
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .90f),

        confirmButton = {
            TextButton(
                onClick = onResume,
                colors = ButtonDefaults.textButtonColors(contentColor = md_onPrimary)
            ) {
                Text(
                    text = stringResource(R.string.dialog_resume_resume),
                    style = MaterialTheme.typography.labelLarge.copy(color = md_onPrimary)
                )
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDiscard,
                colors = ButtonDefaults.textButtonColors(contentColor = md_onPrimary)
            ) {
                Text(
                    text = stringResource(R.string.dialog_resume_new),
                    style = MaterialTheme.typography.labelLarge.copy(color = md_onPrimary)
                )
            }
        }
    )
}
