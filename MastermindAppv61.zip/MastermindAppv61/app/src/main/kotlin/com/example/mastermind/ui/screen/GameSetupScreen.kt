package com.example.mastermind.ui.screen

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mastermind.R
import com.example.mastermind.domain.model.GameSettings
import com.example.mastermind.ui.component.MenuButton
import com.example.mastermind.ui.component.StyledOptionGroup
import com.example.mastermind.ui.component.WoodBackground
import com.example.mastermind.ui.component.isLandscape
import com.example.mastermind.ui.theme.md_onPrimary
import com.example.mastermind.viewmodel.GameViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameSetupScreen(nav: NavHostController) {

    /* ---- shared VM con GameScreen ---- */
    val parentEntry = remember(nav) { nav.getBackStackEntry("game_flow") }
    val vm: GameViewModel = viewModel(parentEntry)

    val current by vm.settings.collectAsState()

    /* ---- stato locale ---- */
    var colors     by remember { mutableStateOf(current.colors.coerceIn(6, 10)) }
    var length     by remember { mutableStateOf(current.codeLength.coerceIn(4, 5)) }
    var duplicates by remember { mutableStateOf(current.allowDuplicates) }
    var attempts   by remember { mutableStateOf(current.maxAttempts) }

    val landscape = isLandscape()
    val scope     = rememberCoroutineScope()

    /* ---- stile “glass” ---- */
    val glassBg    = Color.White.copy(alpha = .15f)
    val glassShape = RoundedCornerShape(24.dp)

    val yesTxt = stringResource(R.string.option_yes)
    val noTxt  = stringResource(R.string.option_no)

    /* ---------------- UI ---------------- */
    WoodBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                LargeTopAppBar(
                    title = {
                        Text(
                            text      = stringResource(R.string.dialog_title_setup),
                            modifier  = Modifier.fillMaxWidth(),
                            style     = MaterialTheme.typography.headlineLarge.copy(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize   = 42.sp,
                                color      = md_onPrimary,
                                shadow     = Shadow(
                                    color = Color.Black.copy(alpha = .4f),
                                    offset = Offset(4f, 4f),
                                    blurRadius = 10f
                                )
                            ),
                            textAlign = TextAlign.Center
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = null, tint = md_onPrimary)
                        }
                    },
                    colors = TopAppBarDefaults.largeTopAppBarColors(containerColor = Color.Transparent)
                )
            }
        ) { inner ->

            val pad = Modifier
                .padding(inner)
                .padding(horizontal = 24.dp, vertical = 18.dp)

            if (landscape) {
                /* ---------------- LANDSCAPE ---------------- */
                Row(
                    modifier = pad.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(24.dp),
                    verticalAlignment     = Alignment.CenterVertically
                ) {

                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        StyledOptionGroup(
                            label    = stringResource(R.string.option_colors),
                            options  = listOf("6", "8", "10"),
                            selected = colors.toString(),
                            onSelect = { colors = it.toInt() }
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        StyledOptionGroup(
                            label    = stringResource(R.string.option_length),
                            options  = listOf("4", "5"),
                            selected = length.toString(),
                            onSelect = { length = it.toInt() }
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        StyledOptionGroup(
                            label    = stringResource(R.string.option_duplicates),
                            options  = listOf(yesTxt, noTxt),
                            selected = if (duplicates) yesTxt else noTxt,
                            onSelect = { duplicates = it == yesTxt }
                        )
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        MenuButton(
                            label           = stringResource(R.string.start),
                            textColor       = md_onPrimary,
                            backgroundColor = glassBg,
                            shape           = glassShape,
                            onClick = {
                                scope.launch {
                                    vm.startNewGame(
                                        GameSettings(colors, length, duplicates, attempts)
                                    )
                                    nav.navigate("game")
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(60.dp)
                        )
                    }
                }
            } else {
                /* ---------------- PORTRAIT ---------------- */
                Column(
                    modifier = pad,
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {

                    StyledOptionGroup(
                        label    = stringResource(R.string.option_colors),
                        options  = listOf("6", "8", "10"),
                        selected = colors.toString(),
                        onSelect = { colors = it.toInt() }
                    )

                    StyledOptionGroup(
                        label    = stringResource(R.string.option_length),
                        options  = listOf("4", "5"),
                        selected = length.toString(),
                        onSelect = { length = it.toInt() }
                    )

                    StyledOptionGroup(
                        label    = stringResource(R.string.option_duplicates),
                        options  = listOf(yesTxt, noTxt),
                        selected = if (duplicates) yesTxt else noTxt,
                        onSelect = { duplicates = it == yesTxt }
                    )

                    Spacer(Modifier.height(32.dp))

                    MenuButton(
                        label           = stringResource(R.string.start),
                        textColor       = md_onPrimary,
                        backgroundColor = glassBg,
                        shape           = glassShape,
                        onClick = {
                            scope.launch {
                                vm.startNewGame(
                                    GameSettings(colors, length, duplicates, attempts)
                                )
                                nav.navigate("game")
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                    )
                }
            }
        }
    }
}
