package com.abc.mastermind.service

import android.content.Context
import android.content.Intent
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.*

// Observer legato al ciclo di vita globale dell'app (ProcessLifecycleOwner).
// Gestisce l'avvio e l'arresto della musica di sottofondo quando l'app entra o esce dal foreground.
// Introduce un ritardo per evitare stop/avvii inutili in caso di ricostruzione veloce dell'Activity.
class AppMusicObserver(private val ctx: Context) : DefaultLifecycleObserver {

    // Job che rappresenta lo stop programmato con ritardo (viene annullato se l'app torna in foreground)
    private var pendingStop: Job? = null

    override fun onStart(owner: LifecycleOwner) {
        // L'app è tornata visibile: annulla eventuale stop pianificato e avvia il servizio musicale
        pendingStop?.cancel()
        pendingStop = null
        ctx.startService(Intent(ctx, BackgroundMusicService::class.java))
    }

    override fun onStop(owner: LifecycleOwner) {
        // L'app non ha più attività visibili: programma lo stop del servizio musicale dopo 300 ms
        pendingStop = CoroutineScope(Dispatchers.Main).launch {
            delay(300)
            ctx.stopService(Intent(ctx, BackgroundMusicService::class.java))
        }
    }
}
