package com.example.mastermind.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.mastermind.data.dao.GameDao
import com.example.mastermind.data.entity.GameEntity
import com.example.mastermind.data.util.Converters

@Database(
    entities = [GameEntity::class],
    version = 8,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class MastermindDatabase : RoomDatabase() {

    abstract fun gameDao(): GameDao

    companion object {
        @Volatile private var INSTANCE: MastermindDatabase? = null

        fun get(context: Context): MastermindDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MastermindDatabase::class.java,
                    "mastermind.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
