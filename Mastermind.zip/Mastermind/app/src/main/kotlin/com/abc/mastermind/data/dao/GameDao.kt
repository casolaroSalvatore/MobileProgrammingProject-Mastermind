package com.abc.mastermind.data.dao

import androidx.room.*
import com.abc.mastermind.data.entity.GameEntity
import kotlinx.coroutines.flow.Flow

// Interfaccia DAO per gestire le operazioni sul database relative alle partite (GameEntity).
// Fornisce metodi per inserire, aggiornare e leggere i dati delle partite,
// sia in modalità "una tantum" che come stream reattivi.
@Dao
interface GameDao {

    // Inserisce una nuova partita nel database.
    // Se esiste già una partita con lo stesso id, la sostituisce.
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(game: GameEntity): Long

    // Imposta lo stato della partita a terminata (ongoing = 0) per l'id specificato.
    @Query("UPDATE game SET ongoing = 0 WHERE id = :id")
    suspend fun markFinished(id: Long)

    // Inserisce una partita e la marca subito come terminata all'interno di una transazione.
    // Questo garantisce che entrambe le operazioni avvengano in modo atomico.
    @Transaction
    suspend fun insertAndFinish(game: GameEntity) {
        val id = insert(game)
        markFinished(id)
    }

    // Recupera la partita in corso, se esiste. Restituisce null se non ce ne sono.
    @Query("SELECT * FROM game WHERE ongoing = 1 LIMIT 1")
    suspend fun getOngoing(): GameEntity?

    // Recupera una partita con l'id indicato. Esegue la query una sola volta.
    @Query("SELECT * FROM game WHERE id = :id")
    suspend fun getByIdOnce(id: Long): GameEntity?

    // Restituisce un Flow con tutte le partite concluse, ordinate dalla più recente.
    @Query("SELECT * FROM game WHERE ongoing = 0 ORDER BY date DESC")
    fun getAllFinished(): Flow<List<GameEntity>>

    // Restituisce un Flow della partita con l'id indicato, aggiornato automaticamente ai cambiamenti.
    @Query("SELECT * FROM game WHERE id = :id")
    fun getById(id: Long): Flow<GameEntity?>
}
