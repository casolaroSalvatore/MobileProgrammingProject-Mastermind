package com.abc.mastermind.service

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import androidx.annotation.RawRes
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/*
   Gestisce la riproduzione di un suono di click con volume regolabile.
*/
object SoundManager {

    private var pool: SoundPool? = null
    private var clickId = 0
    private var loaded = false

    private val _volume = MutableStateFlow(1f)
    val volume = _volume.asStateFlow()

    // Inizializza e carica il suono
    fun init(context: Context, @RawRes res: Int) {
        if (pool != null) return
        pool = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .build()
            )
            .build().also { sp ->
                clickId = sp.load(context, res, 1)
                sp.setOnLoadCompleteListener { _, _, _ -> loaded = true }
            }
    }

    // Imposta il volume (0..1)
    fun setVolume(v: Float) {
        _volume.value = v.coerceIn(0f, 1f)
    }

    // Riproduce il suono se caricato
    fun playClick() {
        if (loaded) {
            val v = volume.value
            pool?.play(clickId, v, v, 1, 0, 1f)
        }
    }

    // Rilascia le risorse
    fun release() {
        pool?.release()
        pool = null
        loaded = false
    }
}
