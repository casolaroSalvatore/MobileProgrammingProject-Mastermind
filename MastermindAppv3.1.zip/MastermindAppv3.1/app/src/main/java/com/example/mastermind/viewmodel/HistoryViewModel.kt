package com.example.mastermind.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.mastermind.data.MastermindDatabase
import com.example.mastermind.data.repository.GameRepository
import com.example.mastermind.domain.model.GameSettings
import com.google.gson.Gson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDateTime

data class HistoryItem(
    val id: Long,
    val date: LocalDateTime,
    val attempts: Int,
    val won: Boolean,
    val settings: GameSettings
)

class HistoryViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = GameRepository(MastermindDatabase.get(app).gameDao())
    private val gson = Gson()
    // Filtri con valori di default
    private val _filterColors = MutableStateFlow(6)
    val filterColors: StateFlow<Int> = _filterColors

    private val _filterCodeLength = MutableStateFlow(4)
    val filterCodeLength: StateFlow<Int> = _filterCodeLength

    private val _filterAllowDuplicates = MutableStateFlow(true)
    val filterAllowDuplicates: StateFlow<Boolean> = _filterAllowDuplicates

    // Lista completa delle partite finite (ongoing = false)
    private val allGames = repo.finished()

    private val _filterEnabled = MutableStateFlow(false)
    val filterEnabled = _filterEnabled.asStateFlow()


    // Lista filtrata in base ai parametri
    val games = combine(
        allGames,
        _filterColors,
        _filterCodeLength,
        _filterAllowDuplicates,
        _filterEnabled
    ) { list, colors, length, duplicates, enabled ->

        val filtered = if (!enabled) {
            list.filter { !it.ongoing }
        } else {
            list.filter { g ->
                val s = gson.fromJson(g.settingsJson, GameSettings::class.java)
                !g.ongoing &&
                        s.colors == colors &&
                        s.codeLength == length &&
                        s.allowDuplicates == duplicates &&
                        g.moves.lastOrNull()?.guess == g.secret
            }.sortedBy { it.moves.size }
        }

        // Mappo in HistoryItem
        filtered.map { g ->
            val s = gson.fromJson(g.settingsJson, GameSettings::class.java)
            HistoryItem(
                id = g.id,
                date = g.date,
                attempts = g.moves.size,
                won = g.moves.lastOrNull()?.guess == g.secret,
                settings = s
            )
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())


    // Funzione per aggiornare i filtri
    // Funzioni per aggiornare filtri e abilitare filtro
    fun setFilters(colors: Int, length: Int, duplicates: Boolean) {
        _filterColors.value = colors
        _filterCodeLength.value = length
        _filterAllowDuplicates.value = duplicates
        _filterEnabled.value = true
    }

    fun clearFilter() {
        _filterEnabled.value = false
    }
}

 /*   val games = repo.finished()
        .map { list ->
            list.map { g ->
                val s = gson.fromJson(g.settingsJson, GameSettings::class.java)
                HistoryItem(
                    id       = g.id,
                    date     = g.date,
                    attempts = g.moves.size,
                    won      = g.moves.lastOrNull()?.guess == g.secret,
                    settings = s
                )
            }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
}
*/



