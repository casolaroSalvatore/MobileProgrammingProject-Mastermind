package com.example.mastermind.internationalization

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.example.mastermind.R

/* Lista di lingue supportate */
data class AppLanguage(
        val code: String,
        @StringRes val label: Int,
        @DrawableRes val icon: Int
    ) {
    companion object {
        val SUPPORTED = listOf(
            AppLanguage("en", R.string.lang_english, R.drawable.ic_flag_en),
            AppLanguage("it", R.string.lang_italian, R.drawable.ic_flag_it),
            AppLanguage("es", R.string.lang_spanish, R.drawable.ic_flag_es),
            AppLanguage("fr", R.string.lang_french, R.drawable.ic_flag_fr),
            AppLanguage("de", R.string.lang_german, R.drawable.ic_flag_de)
        )
    }
}