package com.example.mastermind.ui.component

import android.media.MediaPlayer
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.mastermind.R
import com.example.mastermind.domain.model.GameStatus
import com.example.mastermind.ui.theme.md_onPrimary

@Composable
fun EndOverlay(
    status: GameStatus,
    onNewGame: () -> Unit,
    onBackToMenu: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (status == GameStatus.Playing) return

    val ctx = LocalContext.current

    // Suona il jingle una sola volta
    LaunchedEffect(status) {
        val res = when (status) {
            GameStatus.Won     -> R.raw.victory
            is GameStatus.Lost -> R.raw.defeat
            else               -> null
        }
        res?.let {
            MediaPlayer.create(ctx, it).apply {
                start()
                setOnCompletionListener { release() }
            }
        }
    }

    // Stili “vetro”
    val glassBg    = Color.White.copy(alpha = 0.15f)
    val glassShape = RoundedCornerShape(24.dp)

    Box(
        modifier
            .fillMaxSize()
            .zIndex(1f)
            .background(Color.Black.copy(alpha = 0.6f))
            .clickable(enabled = false) { }
    ) {
        Card(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth(0.85f)
                .wrapContentHeight()
                .padding(16.dp),
            shape = glassShape,
            colors = CardDefaults.cardColors(containerColor = glassBg),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Titolo con font serif, ombra e colore md_onPrimary
                val titleText = when (status) {
                    GameStatus.Won  -> stringResource(R.string.win_title)
                    is GameStatus.Lost -> stringResource(R.string.lose_title)
                    else -> ""
                }
                Text(
                    text = titleText,
                    style = TextStyle(
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 28.sp,
                        shadow = Shadow(
                            color = Color.Black.copy(alpha = 0.3f),
                            offset = Offset(2f, 2f),
                            blurRadius = 4f
                        ),
                        color = md_onPrimary
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(12.dp))

                // Messaggio secondario
                when (status) {
                    GameStatus.Won -> {
                        Text(
                            text = stringResource(R.string.win_message),
                            style = MaterialTheme.typography.bodyMedium.copy(color = md_onPrimary),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    is GameStatus.Lost -> {
                        Text(
                            text = stringResource(R.string.lose_message),
                            style = MaterialTheme.typography.bodyMedium.copy(color = md_onPrimary),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(12.dp))
                        // Mostra i peg segreti (dimensione Int, non Dp)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            status.secret.forEach { peg ->
                                Peg(peg, 32)
                            }
                        }
                    }
                    else -> { /* no-op */ }
                }

                Spacer(Modifier.height(24.dp))

                // Pulsante “Nuova partita”
                Button(
                    onClick = onNewGame,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = glassShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = glassBg,
                        contentColor = md_onPrimary
                    )
                ) {
                    Text(stringResource(R.string.menu_new_game))
                }

                Spacer(Modifier.height(12.dp))

                // Pulsante “Torna al menu”
                OutlinedButton(
                    onClick = onBackToMenu,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = glassShape,
                    border = BorderStroke(1.dp, md_onPrimary),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = glassBg,
                        contentColor = md_onPrimary
                    )
                ) {
                    Text(stringResource(R.string.back_to_menu))
                }
            }
        }
    }
}
