package com.example.mastermind.data.repository

import com.example.mastermind.data.dao.GameDao
import com.example.mastermind.data.entity.GameEntity
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class GameRepository(
    private val dao: GameDao,
    private val io: CoroutineDispatcher = Dispatchers.IO
) {

    /* --- stream --- */
    fun finished(): Flow<List<GameEntity>>     = dao.getAllFinished()
    fun gameById(id: Long): Flow<GameEntity?> = dao.getById(id)

    /* --- once --- */
    suspend fun ongoing(): GameEntity?              = dao.getOngoing()
    suspend fun gameByIdOnce(id: Long): GameEntity? = dao.getByIdOnce(id)

    /* --- write --- */
    suspend fun save(game: GameEntity): Long =
        withContext(io) { dao.insert(game) }

    suspend fun markFinished(id: Long) =
        withContext(io) { dao.markFinished(id) }

    /* Esempio di operazione atomica. */
    suspend fun saveAndFinish(game: GameEntity) =
        withContext(io) { dao.insertAndFinish(game) }
}
