package com.example.mastermind.data.dao

import androidx.room.*
import com.example.mastermind.data.entity.GameEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {

    /* ---------- scrittura ---------- */

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(game: GameEntity): Long

    @Query("UPDATE game SET ongoing = 0 WHERE id = :id")
    suspend fun markFinished(id: Long)

    /* Salvataggio + chiusura in un’unica transazione atomica. */
    @Transaction
    suspend fun insertAndFinish(game: GameEntity) {
        val id = insert(game)
        markFinished(id)
    }

    /* ---------- lettura “una tantum” ---------- */

    @Query("SELECT * FROM game WHERE ongoing = 1 LIMIT 1")
    suspend fun getOngoing(): GameEntity?

    @Query("SELECT * FROM game WHERE id = :id")
    suspend fun getByIdOnce(id: Long): GameEntity?

    /* ---------- lettura reattiva ---------- */

    @Query("SELECT * FROM game WHERE ongoing = 0 ORDER BY date DESC")
    fun getAllFinished(): Flow<List<GameEntity>>

    @Query("SELECT * FROM game WHERE id = :id")
    fun getById(id: Long): Flow<GameEntity?>
}
