package com.abc.mastermind.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.abc.mastermind.data.dao.GameDao
import com.abc.mastermind.data.entity.GameEntity
import com.abc.mastermind.data.util.Converters

// Database Room dell'applicazione per memorizzare le partite di Mastermind.
// Contiene una sola entità (GameEntity) e utilizza un TypeConverter per i tipi complessi.
@Database(
    entities = [GameEntity::class],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class MastermindDatabase : RoomDatabase() {

    // Restituisce l'istanza del GameDao per accedere ai dati delle partite.
    abstract fun gameDao(): GameDao

    companion object {
        @Volatile
        private var INSTANCE: MastermindDatabase? = null

        // Restituisce l'istanza singleton del database.
        // Se non esiste, la crea in modo thread-safe.
        fun get(context: Context): MastermindDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MastermindDatabase::class.java,
                    // Nome del file del database
                    "mastermind.db"
                )
                    // Ricrea il database se lo schema cambia (attenzione: cancella i dati)
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
