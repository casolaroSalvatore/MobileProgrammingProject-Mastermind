package com.abc.mastermind.viewmodel

import android.app.Application
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.abc.mastermind.data.MastermindDatabase
import com.abc.mastermind.data.entity.GameEntity
import com.abc.mastermind.data.entity.Move
import com.abc.mastermind.data.preferences.PreferencesManager
import com.abc.mastermind.data.repository.GameRepository
import com.abc.mastermind.domain.logic.MastermindSolver
import com.abc.mastermind.domain.model.ColorPeg
import com.abc.mastermind.domain.model.GameSettings
import com.abc.mastermind.domain.model.GameStatus
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDateTime

// Riga mostrata nella lista delle mosse nella UI
data class MoveResult(val guess: List<ColorPeg>, val blacks: Int, val whites: Int)

// ViewModel principale per la logica di gioco di Mastermind.
// Gestisce stato partita, mosse, salvataggi e interazione con repository/preferenze.
class GameViewModel(app: Application) : AndroidViewModel(app) {

    // Dipendenze
    private val repo = GameRepository(MastermindDatabase.get(app).gameDao())
    private val pref = PreferencesManager(app)

    // Stato persistente della partita corrente
    private var gameId: Long? = null
    private var secret: List<ColorPeg> = emptyList()
    private val MAX_ATTEMPTS = 9

    // Stato esposto alla UI
    private val _settings = MutableStateFlow(GameSettings())
    val settings: StateFlow<GameSettings> = _settings

    private val _status = MutableStateFlow<GameStatus>(GameStatus.Playing)
    val status: StateFlow<GameStatus> = _status

    private val _unsaved = MutableStateFlow(false)
    val isUnsaved: StateFlow<Boolean> = _unsaved

    private val _moves = MutableStateFlow<List<MoveResult>>(emptyList())
    val moves: StateFlow<List<MoveResult>> = _moves

    private val _editing = MutableStateFlow<List<ColorPeg?>>(emptyList())
    val editing: StateFlow<List<ColorPeg?>> = _editing

    private val _remaining = MutableStateFlow<Int?>(null)
    val remaining: StateFlow<Int?> = _remaining

    // Verifica se il tentativo attuale è valido per invio
    val canSubmit: StateFlow<Boolean> = combine(_editing, _settings) { g, s ->
        g.size == s.codeLength &&
                g.none { it == null } &&
                (s.allowDuplicates || g.filterNotNull().toSet().size == g.size)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    // Stato per debug: codice segreto
    private val _secretFlow = MutableStateFlow<List<ColorPeg>>(emptyList())
    val secretFlow: StateFlow<List<ColorPeg>> = _secretFlow

    // Eventi one-shot per la UI
    sealed interface UiEvent {
        object Saved : UiEvent
        object OverwriteRequired : UiEvent
        object Loaded : UiEvent
    }

    private val _uiEvent = MutableSharedFlow<UiEvent>(extraBufferCapacity = 1)
    val uiEvent = _uiEvent.asSharedFlow()

    init {
        // Inizializza raccogliendo le preferenze e caricando eventuale partita salvata
        viewModelScope.launch {
            var first = true
            pref.settings.collect { cfg ->
                _settings.value = cfg
                if (first) {
                    first = false
                    loadOngoing()
                }
            }
        }
    }

    // Crea una nuova partita
    fun startNewGame(cfg: GameSettings) = viewModelScope.launch {
        pref.save(cfg)
        _settings.value = cfg
        startInternal(cfg)
        _unsaved.value = true
    }

    private suspend fun startInternal(cfg: GameSettings) {
        if (_unsaved.value) gameId?.let { repo.markFinished(it) }

        _status.value = GameStatus.Playing
        _unsaved.value = true

        // Genera il codice segreto
        val palette = ColorPeg.subset(cfg.colors)
        require(cfg.allowDuplicates || cfg.colors >= cfg.codeLength)
        secret = buildList {
            repeat(cfg.codeLength) {
                var next: ColorPeg
                do {
                    next = palette.random()
                } while (!cfg.allowDuplicates && contains(next))
                add(next)
            }
        }
        _secretFlow.value = secret

        // Resetta lo stato UI
        _moves.value = emptyList()
        _editing.value = List(cfg.codeLength) { null }
        _remaining.value = null

        // Salva una nuova partita (non ancora riprendibile)
        gameId = repo.save(
            GameEntity(
                id = 0,
                date = LocalDateTime.now(),
                secret = secret,
                moves = emptyList(),
                editing = emptyList(),
                settings = cfg,
                ongoing = false
            )
        )
    }

    // Carica una partita in corso se esiste
    suspend fun loadOngoing(): Boolean {
        val g = repo.ongoing() ?: return false
        if (!g.ongoing) return false

        gameId = g.id
        secret = g.secret
        _secretFlow.value = secret
        _settings.value = g.settings

        _moves.value = g.moves.map { MoveResult(it.guess, it.blacks, it.whites) }
        _remaining.value = MastermindSolver.remainingCompatible(
            _settings.value,
            _moves.value.map { it.guess to (it.blacks to it.whites) }
        )
        _editing.value = List(_settings.value.codeLength) { null }
        _status.value = GameStatus.Playing
        _uiEvent.emit(UiEvent.Loaded)
        return true
    }

    // Aggiorna un peg nell'editor
    fun updatePeg(index: Int, color: ColorPeg?) =
        _editing.update { it.toMutableList().also { l -> l[index] = color } }

    fun clearEditing() {
        _editing.value = List(_settings.value.codeLength) { null }
    }

    // Conferma il tentativo e aggiorna stato
    @RequiresApi(Build.VERSION_CODES.O)
    fun commitGuess() {
        val guess = _editing.value.filterNotNull()
        val cfg = _settings.value
        if (guess.size != cfg.codeLength) return

        viewModelScope.launch {
            val (b, w) = MastermindSolver.feedback(secret, guess)
            _moves.update { it + MoveResult(guess, b, w) }

            _remaining.value = MastermindSolver.remainingCompatible(
                cfg, _moves.value.map { it.guess to (it.blacks to it.whites) }
            )

            _editing.value = List(cfg.codeLength) { null }

            val finished = when {
                b == secret.size -> {
                    _status.value = GameStatus.Won
                    true
                }

                _moves.value.size >= MAX_ATTEMPTS -> {
                    _status.value = GameStatus.Lost(secret)
                    true
                }

                else -> false
            }

            if (finished) repo.markFinished(gameId!!)
            saveHistory()
        }
    }

    // Salva la partita (con o senza sovrascrivere esistente)
    suspend fun saveGame(overwrite: Boolean = false) {
        val old = repo.ongoing()
        if (old != null && !overwrite) {
            _uiEvent.emit(UiEvent.OverwriteRequired)
            return
        }
        val idPrev = old?.id ?: gameId ?: 0L
        val stillPlaying = _status.value is GameStatus.Playing

        gameId = repo.save(snapshot(idPrev, ongoing = stillPlaying))
        _unsaved.value = false
        _uiEvent.emit(UiEvent.Saved)
    }

    fun saveProgress() = viewModelScope.launch {
        if (_unsaved.value && _status.value is GameStatus.Playing) {
            gameId = repo.save(snapshot(gameId ?: 0L, ongoing = true)).also {
                _unsaved.value = false
                _uiEvent.emit(UiEvent.Saved)
            }
        }
    }

    private fun snapshot(id: Long, ongoing: Boolean) = GameEntity(
        id = id,
        date = LocalDateTime.now(),
        secret = secret,
        moves = _moves.value.map { Move(it.guess, it.blacks, it.whites) },
        editing = _editing.value.filterNotNull(),
        settings = _settings.value,
        ongoing = ongoing
    )

    private suspend fun saveHistory() {
        repo.save(snapshot(gameId ?: 0L, ongoing = false))
        _unsaved.value = true
    }

    // Helpers per menu/dialog resume
    suspend fun getOngoingSummary(): GameEntity? = repo.ongoing()
    fun discardOngoing(id: Long) = viewModelScope.launch { repo.markFinished(id) }
    suspend fun getOngoingGameOnce(): GameEntity? = repo.ongoing()
    fun isPlaying(): Boolean = _status.value is GameStatus.Playing
    fun abandonWithoutSaving() = viewModelScope.launch { gameId?.let { repo.markFinished(it) } }
}
