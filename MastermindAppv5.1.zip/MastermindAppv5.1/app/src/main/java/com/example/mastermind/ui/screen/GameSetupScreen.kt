package com.example.mastermind.ui.screen

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mastermind.R
import com.example.mastermind.domain.model.GameSettings
import com.example.mastermind.ui.component.MenuButton
import com.example.mastermind.ui.component.OptionGroup
import com.example.mastermind.ui.component.WoodBackground
import com.example.mastermind.ui.component.isLandscape
import com.example.mastermind.ui.theme.PegBorder1
import com.example.mastermind.ui.theme.md_onPrimary
import com.example.mastermind.viewmodel.GameViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameSetupScreen(nav: NavHostController) {
    val vm: GameViewModel = viewModel()
    val current by vm.settings.collectAsState()

    val isLandscape = isLandscape()

    var colors by remember { mutableStateOf(current.colors.coerceIn(6, 10)) }
    var length by remember { mutableStateOf(current.codeLength.coerceIn(4, 5)) }
    var duplicates by remember { mutableStateOf(current.allowDuplicates) }
    var attempts by remember { mutableStateOf(current.maxAttempts) }

    WoodBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                LargeTopAppBar(
                    title = {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                                .border(
                                    width = 2.dp,
                                    color = PegBorder1,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .padding(vertical = 12.dp, horizontal = 16.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.dialog_title_setup),
                                modifier = Modifier.fillMaxWidth(),
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 28.sp,
                                    fontFamily = FontFamily.Serif,
                                    color = md_onPrimary,
                                    shadow = Shadow(
                                        color = Color.Black.copy(alpha = 0.3f),
                                        offset = Offset(2f, 2f),
                                        blurRadius = 4f
                                    )
                                ),
                                textAlign = TextAlign.Center
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Icon(Icons.Default.ArrowBack, null)
                        }
                    },
                    colors = TopAppBarDefaults.largeTopAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
            }
        ) { inner ->
            val commonModifier = Modifier
                .padding(inner)
                .padding(horizontal = 24.dp, vertical = 18.dp)

            if (isLandscape) {
                Column(
                    modifier = commonModifier,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = stringResource(R.string.choose_settings),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    )

                    SettingsRowWithStartButton(
                        colors = colors,
                        length = length,
                        duplicates = duplicates,
                        onColorsChange = { colors = it },
                        onLengthChange = { length = it },
                        onDuplicatesChange = { duplicates = it },
                        onStart = {
                            vm.startNewGame(
                                GameSettings(colors, length, duplicates, attempts)
                            )
                            nav.navigate("game")
                        }
                    )
                }
            }
            else {
                Column(
                    modifier = commonModifier,
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    SettingsColumn(
                        colors, length, duplicates,
                        onColorsChange = { colors = it },
                        onLengthChange = { length = it },
                        onDuplicatesChange = { duplicates = it }
                    )
                    Spacer(Modifier.height(32.dp))

                    MenuButton(
                        label = stringResource(R.string.start),
                        onClick = {
                            vm.startNewGame(
                                GameSettings(colors, length, duplicates, attempts)
                            )
                            nav.navigate("game")
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsColumn(
    colors: Int,
    length: Int,
    duplicates: Boolean,
    onColorsChange: (Int) -> Unit,
    onLengthChange: (Int) -> Unit,
    onDuplicatesChange: (Boolean) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Text(
            text = stringResource(R.string.choose_settings),
            style = MaterialTheme.typography.titleLarge.copy(
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
        )
        OptionGroup(
            label = stringResource(R.string.option_colors),
            options = listOf(6, 8, 10),
            selected = colors,
            onSelect = onColorsChange
        )
        OptionGroup(
            label = stringResource(R.string.option_length),
            options = listOf(4, 5),
            selected = length,
            onSelect = onLengthChange
        )
        OptionGroup(
            label = stringResource(R.string.option_duplicates),
            options = listOf(true, false),
            selected = duplicates,
            toString = {
                if (it) stringResource(R.string.option_yes)
                else stringResource(R.string.option_no)
            },
            onSelect = onDuplicatesChange
        )
    }
}

@Composable
private fun SettingsRowWithStartButton(
    colors: Int,
    length: Int,
    duplicates: Boolean,
    onColorsChange: (Int) -> Unit,
    onLengthChange: (Int) -> Unit,
    onDuplicatesChange: (Boolean) -> Unit,
    onStart: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Colori
        Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OptionGroup(
                label = stringResource(R.string.option_colors),
                options = listOf(6, 8, 10),
                selected = colors,
                onSelect = onColorsChange
            )
        }

        // Lunghezza
        Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OptionGroup(
                label = stringResource(R.string.option_length),
                options = listOf(4, 5),
                selected = length,
                onSelect = onLengthChange
            )
        }

        // Duplicati
        Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OptionGroup(
                label = stringResource(R.string.option_duplicates),
                options = listOf(true, false),
                selected = duplicates,
                toString = {
                    if (it) stringResource(R.string.option_yes) else stringResource(R.string.option_no)
                },
                onSelect = onDuplicatesChange
            )
        }

        // Pulsante Avvia
        Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            MenuButton(
                label = stringResource(R.string.start),
                onClick = onStart,
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(48.dp)
            )
        }
    }
}
