package com.abc.mastermind.ui.component

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.abc.mastermind.ui.theme.PegBorder1
import com.abc.mastermind.ui.theme.md_onPrimary

// Composable che rappresenta un pulsante stilizzato per il menu.
// Supporta un'icona opzionale accanto al testo e uno stile personalizzabile.
@Composable
fun MenuButton(
    label: String,                                          // Testo da mostrare sul pulsante
    textColor: Color = md_onPrimary,                        // Colore del testo (e icona se presente)
    backgroundColor: Color = PegBorder1,                    // Colore di sfondo del pulsante
    icon: ImageVector? = null,                              // Icona opzionale da mostrare a sinistra del testo
    iconSpacing: Dp = 8.dp,                                 // Spaziatura tra icona e testo
    shape: RoundedCornerShape = RoundedCornerShape(12.dp),  // Forma del pulsante
    enabled: Boolean = true,                                // Abilitazione del pulsante
    onClick: () -> Unit,                                    // Callback chiamata al click
    modifier: Modifier = Modifier                           // Modificatore per personalizzare il pulsante
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier,
        shape = shape,
        colors = ButtonDefaults.buttonColors(containerColor = backgroundColor)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = textColor
                )
                if (label.isNotBlank()) {
                    Spacer(modifier = Modifier.width(iconSpacing))
                }

            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = textColor
            )
        }
    }
}

