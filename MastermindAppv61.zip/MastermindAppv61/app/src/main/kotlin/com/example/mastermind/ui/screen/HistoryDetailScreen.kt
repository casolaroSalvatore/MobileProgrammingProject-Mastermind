package com.example.mastermind.ui.screen

import android.app.Activity
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mastermind.R
import com.example.mastermind.data.MastermindDatabase
import com.example.mastermind.data.repository.GameRepository
import com.example.mastermind.ui.component.BoardRow
import com.example.mastermind.ui.component.Peg
import com.example.mastermind.ui.component.WoodBackground
import com.example.mastermind.ui.component.isLandscape
import com.example.mastermind.ui.theme.md_onPrimary
import com.example.mastermind.viewmodel.HistoryDetailViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryDetailScreen(
    gameId: Long,
    nav: NavHostController
) {
    // ViewModel
    val ctx = LocalContext.current.applicationContext
    val vm: HistoryDetailViewModel = viewModel(
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val repo = GameRepository(MastermindDatabase.get(ctx).gameDao())
                return HistoryDetailViewModel(repo, gameId) as T
            }
        }
    )

    // State
    val rows     by vm.rows.collectAsState()
    val secret   by vm.secret.collectAsState()
    val date     by vm.formattedDate.collectAsState()
    val settings by vm.settings.collectAsState()

    val landscape = isLandscape()

    WoodBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                LargeTopAppBar(
                    title = {
                        Text(
                            text      = stringResource(R.string.history_detail_title),
                            modifier  = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            style     = MaterialTheme.typography.headlineLarge.copy(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize   = 42.sp,
                                color      = md_onPrimary,
                                shadow     = Shadow(
                                    color      = Color.Black.copy(alpha = .4f),
                                    offset     = Offset(4f, 4f),
                                    blurRadius = 10f
                                )
                            ),
                            textAlign = TextAlign.Center
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Icon(
                                Icons.Default.ArrowBack,
                                contentDescription = null,
                                tint = md_onPrimary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.largeTopAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
            }
        ) { inner ->
            val contentPadding = Modifier
                .padding(inner)
                .padding(horizontal = 24.dp, vertical = 16.dp)

            if (landscape) {
                // LANDSCAPE: meta+secret a sinistra, mosse a destra
                Row(
                    modifier = contentPadding.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // data
                        Text(
                            text = date,
                            style = MaterialTheme.typography.bodyMedium.copy(color = md_onPrimary)
                        )
                        // settings
                        settings?.let {
                            Text(
                                text = stringResource(
                                    R.string.history_detail_attempts_palette,
                                    rows.size,
                                    it.maxAttempts,
                                    it.colors
                                ),
                                style = MaterialTheme.typography.labelMedium.copy(color = md_onPrimary)
                            )
                        }
                        // secret code
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = stringResource(R.string.label_secret_code),
                                style = MaterialTheme.typography.titleMedium.copy(color = md_onPrimary)
                            )
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                secret.forEach { Peg(it) }
                            }
                        }
                    }
                    // lista mosse
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(rows) { m ->
                            BoardRow(m.guess, m.blacks, m.whites)
                        }
                    }
                }
            } else {
                // PORTRAIT: tutto in colonna
                Column(
                    modifier = contentPadding.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // data
                    Text(
                        text = date,
                        style = MaterialTheme.typography.bodyMedium.copy(color = md_onPrimary)
                    )
                    // settings
                    settings?.let {
                        Text(
                            text = stringResource(
                                R.string.history_detail_attempts_palette,
                                rows.size,
                                it.maxAttempts,
                                it.colors
                            ),
                            style = MaterialTheme.typography.labelMedium.copy(color = md_onPrimary)
                        )
                    }
                    // secret code
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = stringResource(R.string.label_secret_code),
                            style = MaterialTheme.typography.titleMedium.copy(color = md_onPrimary)
                        )
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            secret.forEach { Peg(it) }
                        }
                    }
                    // mosse
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(rows) { m ->
                            BoardRow(m.guess, m.blacks, m.whites)
                        }
                    }
                }
            }
        }
    }
}

