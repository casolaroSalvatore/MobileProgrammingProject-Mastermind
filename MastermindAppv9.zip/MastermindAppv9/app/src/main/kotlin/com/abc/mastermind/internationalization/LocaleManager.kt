package com.abc.mastermind.internationalization

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.abc.mastermind.data.preferences.PreferencesManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

// Gestisce la lingua dell'applicazione: applica la lingua selezionata e la salva nelle preferenze.
object LocaleManager {

    // Applica il codice della lingua specificato creando il corrispondente LocaleListCompat.
    private fun apply(code: String?) {
        val locales = code
            ?.takeIf { it.isNotBlank() }
            ?.let { LocaleListCompat.forLanguageTags(it) }
            ?: LocaleListCompat.getEmptyLocaleList()
        AppCompatDelegate.setApplicationLocales(locales)
    }

    // Inizializza la lingua al primo avvio dell'app leggendo la preferenza salvata.
    suspend fun init(ctx: Context) {
        val code = PreferencesManager(ctx).language.first()
        apply(code)
    }

    // Cambia la lingua durante l'esecuzione:
    // 1. Applica subito la lingua selezionata.
    // 2. Salva la lingua scelta nel DataStore in background.
    fun change(ctx: Context, code: String) {
        apply(code) // Applica immediatamente la nuova lingua
        CoroutineScope(Dispatchers.IO).launch {
            PreferencesManager(ctx).setLanguage(code)
        }
    }
}
