package com.abc.mastermind.data.repository

import com.abc.mastermind.data.dao.GameDao
import com.abc.mastermind.data.entity.GameEntity
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

// Repository che funge da intermediario tra il GameDao e il resto dell'applicazione.
// Fornisce metodi per accedere e modificare i dati relativi alle partite,
// eseguendo le operazioni nel contesto di un dispatcher I/O.
class GameRepository(
    private val dao: GameDao,
    private val io: CoroutineDispatcher = Dispatchers.IO // Dispatcher per le operazioni di I/O
) {

    // Restituisce uno stream (Flow) di tutte le partite concluse, aggiornato in tempo reale.
    fun finished(): Flow<List<GameEntity>> = dao.getAllFinished()

    // Restituisce uno stream (Flow) della partita con l'id specificato.
    fun gameById(id: Long): Flow<GameEntity?> = dao.getById(id)

    // Recupera la partita attualmente in corso, se esiste. Operazione una tantum.
    suspend fun ongoing(): GameEntity? = dao.getOngoing()

    // Recupera la partita con l'id specificato. Operazione una tantum.
    suspend fun gameByIdOnce(id: Long): GameEntity? = dao.getByIdOnce(id)

    // Salva una partita nel database eseguendo l'operazione nel dispatcher I/O.
    suspend fun save(game: GameEntity): Long =
        withContext(io) { dao.insert(game) }

    // Marca una partita come terminata eseguendo l'operazione nel dispatcher I/O.
    suspend fun markFinished(id: Long) =
        withContext(io) { dao.markFinished(id) }

    // Salva e termina una partita in un'unica operazione atomica, nel dispatcher I/O.
    suspend fun saveAndFinish(game: GameEntity) =
        withContext(io) { dao.insertAndFinish(game) }
}
