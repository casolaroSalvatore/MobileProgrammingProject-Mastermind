package com.example.mastermind.ui.screen

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mastermind.R
import com.example.mastermind.ui.component.WoodBackground
import com.example.mastermind.viewmodel.HistoryViewModel
import java.time.format.DateTimeFormatter

/* Lista delle partite concluse. Tapping su un item porta a HistoryDetailScreen. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(nav: NavHostController) {

    val vm: HistoryViewModel = viewModel()
    val list by vm.games.collectAsState()

    val fmt = remember {
        DateTimeFormatter.ofPattern("dd MMM yyyy – HH:mm")
    }

    WoodBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                SmallTopAppBar(
                    title = { Text(stringResource(R.string.title_history)) },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Icon(Icons.Default.ArrowBack, null)
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
            }
        ) { inner ->
            if (list.isEmpty()) {
                Box(
                    Modifier
                        .padding(inner)
                        .fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(stringResource(R.string.history_empty))
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .padding(inner)
                        .padding(8.dp)
                        .fillMaxSize()
                ) {
                    items(
                        items = list,
                        key = { it.id }
                    ) { h ->
                        ListItem(
                            headlineContent = { Text(h.date.format(fmt)) },
                            supportingContent = {
                                Text(
                                    stringResource(
                                        R.string.history_item_fmt,
                                        h.attempts,
                                        h.settings.colors,
                                        if (h.won) stringResource(R.string.history_win) else stringResource(R.string.history_lose)
                                    )
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    nav.navigate("historyDetail/${h.id}")
                                }
                        )
                        Divider()
                    }
                }
            }
        }
    }
}