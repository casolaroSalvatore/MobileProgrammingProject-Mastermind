package com.example.mastermind.internationalization

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.example.mastermind.data.preferences.PreferencesManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

object LocaleManager {

    private fun apply(code: String?) {
        val locales = code
            ?.takeIf { it.isNotBlank() }
            ?.let { LocaleListCompat.forLanguageTags(it) }
            ?: LocaleListCompat.getEmptyLocaleList()
        AppCompatDelegate.setApplicationLocales(locales)
    }

    /* Chiamata all’avvio (solo una volta) */
    suspend fun init(ctx: Context) {
        val code = PreferencesManager(ctx).language.first()
        apply(code)
    }

    /* Chiamata dal ViewModel dopo il tap */
    fun change(ctx: Context, code: String) {
        // 1. ri-applica subito in memoria
        apply(code)
        // 2. salva in DataStore (in background)
        CoroutineScope(Dispatchers.IO).launch {
            PreferencesManager(ctx).setLanguage(code)
        }
    }
}
