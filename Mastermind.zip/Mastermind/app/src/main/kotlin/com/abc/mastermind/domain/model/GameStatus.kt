package com.abc.mastermind.domain.model

// Rappresenta lo stato corrente della partita di Mastermind.
// Può essere in corso, vinta o persa (in questo caso contiene la combinazione segreta).
interface GameStatus {
    // Stato: la partita è ancora in corso.
    object Playing : GameStatus

    // Stato: la partita è stata vinta.
    object Won : GameStatus

    // Stato: la partita è stata persa; contiene la combinazione segreta da mostrare al giocatore.
    data class Lost(val secret: List<ColorPeg>) : GameStatus
}
