package com.example.mastermind.ui.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mastermind.R
import com.example.mastermind.data.entity.GameEntity
import com.example.mastermind.ui.component.MenuButton
import com.example.mastermind.ui.component.isLandscape
import com.example.mastermind.viewmodel.GameViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuScreen(nav: NavHostController) {

    val vm: GameViewModel = viewModel()
    val scope             = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val ctx               = LocalContext.current

    val isLandscape = isLandscape()

    /* stato per il dialog Resume/New */
    var savedGame by remember { mutableStateOf<GameEntity?>(null) }
    var showDlg   by remember { mutableStateOf(false) }

    val hostContent: @Composable (SnackbarHostState) -> Unit = { host ->
        SnackbarHost(host) { data ->
            Snackbar(
                snackbarData  = data,
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor   = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }

    /* ----- Dialog Resume/New dentro la Home ----- */
    savedGame?.let { g ->
        if (showDlg) {
            ResumePromptDialog(
                game = g,
                onResume = {
                    showDlg = false
                    scope.launch { vm.loadOngoing() }
                    nav.navigate("game")
                },
                onDiscard = {
                    scope.launch { vm.discardOngoing(g.id) }
                    showDlg = false
                    nav.navigate("setup")
                }
            )
        }
    }

    val background = painterResource(id = R.drawable.menu_background)

    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        Image(
            painter = background,
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.matchParentSize()
        )
        // Contenuto sovrapposto allo sfondo
        Scaffold(
            containerColor = Color.Transparent
        ) { innerPadding ->

            if (isLandscape) {
                Column(
                    modifier = Modifier
                        .padding(innerPadding)
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Bottone Play (più stretto)
                    MenuButton(
                        label = stringResource(R.string.title_game),
                        icon = Icons.Default.PlayArrow,
                        onClick = { nav.navigate("setup") },
                        modifier = Modifier
                            .fillMaxWidth(0.35f) // Ridotto da 0.4f a 0.3f
                            .height(55.dp)       // Altezza leggermente ridotta
                            .padding(vertical = 8.dp)
                    )

                    // Bottone Classifica (più stretto)
                    MenuButton(
                        label = stringResource(R.string.title_history),
                        icon = Icons.Default.Leaderboard,
                        onClick = { nav.navigate("history") },
                        modifier = Modifier
                            .fillMaxWidth(0.3f) // Ridotto da 0.35f a 0.25f
                            .height(58.dp)       // Altezza leggermente ridotta
                            .padding(vertical = 8.dp)
                    )

                    // Riga Resume + Settings (più bassa)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth(0.3f)
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        MenuButton(
                            label = stringResource(R.string.title_resume),
                            icon = Icons.Default.Restore,
                            onClick = { nav.navigate("resume") },
                            modifier = Modifier
                                .weight(0.9f)
                                .height(45.dp) // Altezza ridotta
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        MenuButton(
                            label = "",
                            icon = Icons.Default.Settings,
                            onClick = { nav.navigate("settings") },
                            modifier = Modifier
                                .weight(0.4f)
                                .height(45.dp) // Altezza ridotta
                        )
                    }
                }
            }
            else {
                // LAYOUT PORTRAIT (come nel tuo codice originale)
                Column(
                    modifier = Modifier
                        .padding(innerPadding)
                        .fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    MenuButton(
                        label = stringResource(R.string.title_game),
                        icon = Icons.Default.PlayArrow,
                        onClick = { nav.navigate("setup") },
                        modifier = Modifier
                            .fillMaxWidth(0.7f)
                            .padding(vertical = 16.dp)
                            .height(60.dp)
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 32.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        MenuButton(
                            label = stringResource(R.string.title_history),
                            icon = Icons.Default.Leaderboard,
                            onClick = { nav.navigate("history") },
                            modifier = Modifier
                                .fillMaxWidth(0.6f)
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth(0.8f),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            MenuButton(
                                label = stringResource(R.string.title_resume),
                                icon = Icons.Default.Restore,
                                onClick = { nav.navigate("resume") },
                                modifier = Modifier.weight(1f)
                            )

                            Spacer(modifier = Modifier.width(16.dp))

                            MenuButton(
                                label = "",
                                icon = Icons.Default.Settings,
                                onClick = { nav.navigate("settings") },
                                modifier = Modifier.weight(0.6f)
                            )
                        }
                    }
                }
            }
        }
    }
}