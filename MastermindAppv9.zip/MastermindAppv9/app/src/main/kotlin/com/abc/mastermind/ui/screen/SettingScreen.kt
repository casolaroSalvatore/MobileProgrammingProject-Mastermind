package com.abc.mastermind.ui.screen

import android.app.Activity
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mastermind.R
import com.abc.mastermind.internationalization.AppLanguage
import com.abc.mastermind.ui.component.WoodBackground
import com.abc.mastermind.ui.component.isLandscape
import com.abc.mastermind.ui.theme.md_onPrimary
import com.abc.mastermind.viewmodel.SettingViewModel

// Schermata impostazioni: audio e lingua. Gestisce layout portrait/landscape e ricrea l'activity su cambio lingua.
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingScreen(nav: NavHostController) {

    // ViewModel e stati osservati
    val vm: SettingViewModel = viewModel()
    val musicVol by vm.musicVolume.collectAsStateWithLifecycle()
    val sfxVol by vm.sfxVolume.collectAsStateWithLifecycle()
    val langCode by vm.language.collectAsStateWithLifecycle()
    val ctx by rememberUpdatedState(LocalContext.current)
    val landscape = isLandscape()
    val chipBackgroundColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
    val chipLabelColor = MaterialTheme.colorScheme.onPrimary
    val lightTransparent = Color.White.copy(alpha = 0.15f)


    // Listener per cambio lingua: forza recreate
    LaunchedEffect(Unit) {
        vm.uiEvent.collect { ev ->
            if (ev == SettingViewModel.UiEvent.LanguageChanged) {
                Log.d("LOCALE", "RECREATE after language change")
                (ctx as? Activity)?.recreate()
            }
        }
    }

    WoodBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                LargeTopAppBar(
                    title = {
                        Text(
                            text = stringResource(R.string.title_settings),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 42.sp,
                                color = md_onPrimary,
                                shadow = Shadow(
                                    color = Color.Black.copy(alpha = .4f),
                                    offset = Offset(4f, 4f),
                                    blurRadius = 10f
                                )
                            ),
                            textAlign = TextAlign.Center
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Icon(
                                Icons.Default.ArrowBack,
                                contentDescription = null,
                                tint = md_onPrimary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.largeTopAppBarColors(containerColor = Color.Transparent)
                )
            }
        ) { inner ->
            if (landscape) {
                // LANDSCAPE: colonne affiancate per audio e lingua
                Column(
                    Modifier
                        .padding(inner)
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        stringResource(R.string.section_audio),
                        style = MaterialTheme.typography.titleMedium.copy(color = md_onPrimary),
                        textAlign = TextAlign.Center
                    )
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        SettingColumnSection(
                            title = stringResource(R.string.music_volume, (musicVol * 100).toInt()),
                            sliderValue = musicVol,
                            onValueChange = vm::setMusicVolume
                        )
                        SettingColumnSection(
                            title = stringResource(R.string.sfx_volume, (sfxVol * 100).toInt()),
                            sliderValue = sfxVol,
                            onValueChange = vm::setSfxVolume
                        )
                        LanguageDropdown(
                            currentLangCode = langCode,
                            onLangSelected = {
                                vm.setLanguage(it)
                                (ctx as? Activity)?.recreate()
                            }
                        )
                    }
                }
            } else {
                // PORTRAIT: elementi in colonna
                Column(
                    Modifier
                        .padding(inner)
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Text(
                        stringResource(R.string.section_audio),
                        style = MaterialTheme.typography.titleMedium.copy(color = md_onPrimary)
                    )
                    Text(
                        stringResource(R.string.music_volume, (musicVol * 100).toInt()),
                        color = md_onPrimary
                    )
                    Slider(
                        value = musicVol,
                        onValueChange = vm::setMusicVolume,
                        valueRange = 0f..1f
                    )
                    Text(
                        stringResource(R.string.sfx_volume, (sfxVol * 100).toInt()),
                        color = md_onPrimary
                    )
                    Slider(
                        value = sfxVol,
                        onValueChange = vm::setSfxVolume,
                        valueRange = 0f..1f
                    )
                    Text(
                        stringResource(R.string.section_language),
                        style = MaterialTheme.typography.titleMedium.copy(color = md_onPrimary)
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        AppLanguage.SUPPORTED.forEach { lang ->
                            FilterChip(
                                leadingIcon = {
                                    Icon(
                                        painterResource(lang.icon),
                                        contentDescription = null,
                                        tint = Color.Unspecified
                                    )
                                },
                                selected = lang.code == langCode,
                                onClick = {
                                    vm.setLanguage(lang.code)
                                    (ctx as? Activity)?.recreate()
                                },
                                label = {
                                    Text(stringResource(lang.label), color = md_onPrimary)
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = lightTransparent,
                                    selectedContainerColor = chipBackgroundColor,
                                    selectedLabelColor = chipLabelColor,
                                    selectedLeadingIconColor = chipLabelColor,
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

// Helper composable per slider con titolo
@Composable
private fun SettingColumnSection(
    title: String,
    sliderValue: Float,
    onValueChange: (Float) -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.widthIn(min = 200.dp, max = 300.dp)
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleMedium.copy(color = md_onPrimary),
            textAlign = TextAlign.Center
        )
        Slider(
            value = sliderValue,
            onValueChange = onValueChange,
            valueRange = 0f..1f
        )
    }
}

// Helper composable per selezione lingua (landscape)
@Composable
private fun LanguageDropdown(
    currentLangCode: String,
    onLangSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val selected = AppLanguage.SUPPORTED.first { it.code == currentLangCode }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            stringResource(R.string.section_language),
            style = MaterialTheme.typography.titleMedium.copy(color = md_onPrimary),
            textAlign = TextAlign.Center
        )
        Box {
            OutlinedButton(onClick = { expanded = true }) {
                Text(stringResource(selected.label), color = md_onPrimary)
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                AppLanguage.SUPPORTED.forEach { lang ->
                    DropdownMenuItem(
                        text = { Text(stringResource(lang.label), color = md_onPrimary) },
                        onClick = {
                            expanded = false
                            onLangSelected(lang.code)
                        }
                    )
                }
            }
        }
    }
}
