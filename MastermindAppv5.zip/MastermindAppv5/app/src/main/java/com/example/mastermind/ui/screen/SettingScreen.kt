package com.example.mastermind.ui.screen

import android.app.Activity
import android.util.Log
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mastermind.R
import com.example.mastermind.ui.component.WoodBackground
import com.example.mastermind.viewmodel.SettingViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mastermind.internationalization.AppLanguage
import com.example.mastermind.ui.theme.PegBorder1
import com.example.mastermind.ui.theme.md_onPrimary

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingScreen(nav: NavHostController) {

    val vm: SettingViewModel = viewModel()
    val musicVol by vm.musicVolume.collectAsStateWithLifecycle()
    val sfxVol by vm.sfxVolume.collectAsStateWithLifecycle()
    val langCode by vm.language.collectAsStateWithLifecycle()
    val currentCtx by rememberUpdatedState(LocalContext.current)  // rappresenta l'activity corrente

    /* Ascolto gli UiEvent */
    LaunchedEffect(Unit) {
        vm.uiEvent.collect { ev ->
            if (ev == SettingViewModel.UiEvent.LanguageChanged) {
                Log.d("LOCALE", "SCREEN     ➜ recreating activity")
                (currentCtx as? Activity)?.recreate()
            }
        }
    }

    WoodBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                LargeTopAppBar(
                    title = {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                                .border(
                                    width = 2.dp,
                                    color = PegBorder1,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .padding(vertical = 12.dp, horizontal = 16.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.title_settings),
                                modifier = Modifier.fillMaxWidth(),
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 28.sp,
                                    fontFamily = FontFamily.Serif,
                                    color = md_onPrimary,
                                    shadow = Shadow(
                                        color = Color.Black.copy(alpha = 0.3f),
                                        offset = Offset(2f, 2f),
                                        blurRadius = 4f
                                    )
                                ),
                                textAlign = TextAlign.Center
                            )
                        }
                    },
                    navigationIcon = { IconButton({ nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null) } },
                    colors = TopAppBarDefaults.largeTopAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
            }
        ) { inner ->
            Column(
                Modifier.padding(inner).padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                // Sezione AUDIO
                Text(
                    stringResource(R.string.section_audio),
                    style = MaterialTheme.typography.titleMedium
                )

                /* Musica di sottofondo */
                Text(stringResource(R.string.music_volume, (musicVol * 100).toInt()))
                Slider(
                    value = musicVol,
                    onValueChange = vm::setMusicVolume,
                    valueRange = 0f..1f
                )

                /* Effetti sonori */
                Text(stringResource(R.string.sfx_volume, (sfxVol * 100).toInt()))
                Slider(
                    value = sfxVol,
                    onValueChange = vm::setSfxVolume,
                    valueRange = 0f..1f
                )

                /* ---------- Lingua ---------- */
                Text(stringResource(R.string.section_language),
                    style = MaterialTheme.typography.titleMedium)

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement   = Arrangement.spacedBy(12.dp)
                ) {
                    AppLanguage.SUPPORTED.forEach { lang ->
                        val activity = LocalContext.current as Activity
                        FilterChip(
                            selected = lang.code == langCode,
                            onClick = {
                                vm.setLanguage(lang.code)
                                activity.recreate()
                                activity.overridePendingTransition(0, 0)
                            },
                            label = { Text(stringResource(lang.label)) }
                        )
                        }
                    }

                /* spazio per future impostazioni (tema, vibrazione, …) */

            }
        }
    }
}

@Composable
private fun ChoiceChips(options: List<Int>, selected: Int, onSelect: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { num ->
            FilterChip(
                selected = num == selected,
                onClick = { onSelect(num) },
                label = { Text(num.toString()) }
            )
        }
    }
}

